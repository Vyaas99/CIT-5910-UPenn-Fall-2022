package courses;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testToString() {
		String courseID = "CIT590";
		String coursename = "Programming Languages and Techniques";
		String lecturer = "Brandon L Krakowsky";
		String days = "MW";
		LocalTime begin = LocalTime.of(16, 30);
		LocalTime end = LocalTime.of(18, 0);
		int capacity = 110;
		Course courseTest = new Course(courseID, coursename, lecturer, days, begin, end, capacity);
		System.out.println(courseTest);
		
		//Test Case 1
		assertEquals(courseTest.toString(), "CIT590| Programming Languages and Techniques; Brandon L Krakowsky; MW; 16:30; 18:00; 110");
	}

}
