package courses;
import java.time.LocalTime;

/**
 * Defines a single course
 * @author Felix Yuzhou Sun
 */

public class Course {
	
	//variables
	/**
	 * The course ID
	 */
	private String courseID;
	
	/**
	 * The name of this course
	 */
	private String courseName;
	
	/**
	 * The lecturer of this course
	 */
	private String lecturer;
	
	/**
	 * The course schedule for each week, e.g. MWF
	 */
	private String days;
	
	/**
	 * The start time of the course
	 */
	private LocalTime startTime;
	
	/**
	 * The end time of the course
	 */
	private LocalTime endTime;
	
	/**
	 * The capacity of the course
	 */
	private int capacity;
	
	//constructor
	/**
	 * Set up the properties of a course
	 * @param courseID
	 * @param courseName
	 * @param lecturer
	 * @param days
	 * @param startTime
	 * @param endTime
	 * @param capacity
	 */
	public Course(String courseID, String courseName, String lecturer, String days, LocalTime startTime, LocalTime endTime, int capacity) {
		
		this.courseID = courseID;
		this.courseName = courseName;
		this.lecturer = lecturer;
		this.days = days;
		this.startTime = startTime;
		this.endTime = endTime;
		this.capacity = capacity;
	}
	
	/**
	 * getter method to return start time
	 * @return
	 */
	public LocalTime getStartTime() {
		return this.startTime;
	}
	
	/**
	 * getter method to return end time
	 * @return
	 */
	public LocalTime getEndTime() {
		return this.endTime;
	}
	
	/**
	 * getter method to return course id
	 * @return
	 */
	public String getCourseID() {
		return this.courseID;
	}
	/**
	 * getter method to return course name
	 * @return
	 */
	public String getCourseName() {
		return this.courseName;
	}
	
	/**
	 * getter method to return lecturer
	 * @return
	 */
	public String getLecturer() {
		return this.lecturer;
	}
	
	/**
	 * getter method to return days of the course
	 * @return
	 */
	public String getDays() {
		return this.days;
	}
	
	/**
	 * getter method to return capacity
	 * @return
	 */
	public int getCapacity() {
		return this.capacity;
	}
	
	/**
	 * Print the object as a string
	 */
	public String toString() {
		return this.courseID + "| " + this.courseName + "; " + this.lecturer + "; " + this.days + "; " + this.startTime.toString() + "; " 
				+ this.endTime.toString() + "; " + this.capacity;
		
	}

}
