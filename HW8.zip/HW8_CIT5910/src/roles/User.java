package roles;
/**
 * Class defines every type of user as a superclass, extends to Student, Professor, and Admin. 
 * Contains name, ID, username, password, user type
 * @author Felix Yuzhou Sun
 */

public abstract class User {
	
	//variables
	/**
	 * The id of the user 
	 */
	private int id;
	
	/**
	 * The legal name of the user
	 */
	private String name;
	
	/**
	 * The username of the user
	 */
	private String username;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * The password of the user
	 */
	private String password;
	
	
	//Constructor
	/**
	 * Set up the property of a user
	 * @param id
	 * @param name
	 * @param username
	 * @param password
	 * @param userType
	 */
	public User(int id, String name, String username, String password) {	
		this.id = id;
		this.name = name;
		this.username = username;
		this.password = password;
	} 
	
	/**
	 * Print the object as a string
	 */
	public String toString() {
		return this.name;
		
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	public String getName() {
		return this.name;
	}
	
}
