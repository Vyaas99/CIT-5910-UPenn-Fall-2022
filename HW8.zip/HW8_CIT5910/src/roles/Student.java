package roles;
import java.util.ArrayList;
import java.util.HashMap;

import courses.Course;

/**
 * Defines Student as a subclass extending User superclass
 * @author Felix Yuzhou Sun
 */

public class Student extends User {
	
	//variables
	
	/**
	 * The transcript that contains course ID and the related score
	 */
	private HashMap<String, String> transcript;
	
	/**
	 * Set up the properties of a student
	 * @param id
	 * @param name
	 * @param username
	 * @param password
	 * @param userType
	 * @param transcript
	 */
	
	/**
	 * Array list that contains the courses of the student
	 */
	private ArrayList<Course> courseList= new ArrayList<Course>();
	
	/**
	 * constructor
	 * @param id
	 * @param name
	 * @param username
	 * @param password
	 * @param transcript
	 */
	public Student(int id, String name, String username, String password, HashMap<String, String> transcript) {
		super(id, name, username, password);
		this.transcript = transcript;
		
		
	}
	
	/**
	 * adds course to the course list
	 * @param courseObj
	 */
	public void addCourse(Course courseObj) {
		this.courseList.add(courseObj);
	}
	
	/**
	 * getter method to return course list
	 * @return
	 */
	public ArrayList<Course> getCourseList(){
		return this.courseList;
	}
	
	/**
	 * getter method to return transcript
	 * @return
	 */
	public HashMap<String, String> getTranscript(){
		return this.transcript;
	}
	
}
