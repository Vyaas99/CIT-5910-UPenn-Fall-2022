package roles;

/**
 * Defines Admin as a subclass extending User superclass
 * @author Felix Yuzhou Sun
 */
 
public class Admin extends User {
	
	/**
	 * Set up the properties of an admin
	 * @param id
	 * @param name
	 * @param username
	 * @param user
	 * @param userType
	 */
	public Admin(int id, String name, String username, String password) {
		super(id, name, username, password);
	}

}
