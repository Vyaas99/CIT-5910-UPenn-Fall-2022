package roles;

import java.util.ArrayList;

import courses.Course;

/**
 * Defines Professor as a subclass extending User superclass
 * @author Felix Yuzhou Sun
 */

public class Professor extends User {
	
	
	/**
	 * Set up the properties of a professor
	 * @param id
	 * @param name
	 * @param username
	 * @param user
	 * @param userType
	 */
	public Professor(int id, String name, String username, String password) {
		super(id, name, username, password);

	}
	/**
	 * Array list that contains the courses the professor teaches
	 */
	private ArrayList<Course> courses=new ArrayList<Course>();
	
	/**
	 * getter method to return courses
	 * @return
	 */
	public ArrayList<Course> getCourses(){
		return this.courses;
	}
	/**
	 * Array list that contains the students of the professor
	 */
	private ArrayList<Student> studentList=new ArrayList<Student>();
	
	/**
	 * getter method to return students
	 * @return
	 */
	public ArrayList<Student> getStudentList(){
		return this.studentList;
	}
	

}
