
public class sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="1";
		int b=Integer.parseInt(a);
		System.out.println(b);

	}

}
