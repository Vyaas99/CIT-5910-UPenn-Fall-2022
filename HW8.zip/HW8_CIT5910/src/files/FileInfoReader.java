package files;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalTime;
import java.util.HashMap;
import courses.Course;
import roles.Admin;
import roles.Professor;
import roles.Student;

/**
 * Read the information from the local files into the system
 * @author Felix Yuzhou Sun
 */
public class FileInfoReader {


	/**
	 * Load all the course informations into the DB
	 */
	public HashMap<String, Course> readCourses(String inputFile) {

		HashMap<String, Course> allCourses = new HashMap<String, Course>();

		//create file object
		File file = new File(inputFile);	
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		//create filereader from file
		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);

			String line;

			//read each line in file until we reach the EOF
			while ((line = bufferedReader.readLine()) != null) {

				//split on whitespace (one space or more)
				//gives me array of strings from line
				String[] resultArray = line.trim().split(";");
				String courseID = resultArray[0].trim();
				String courseName = resultArray[1].trim();
				String lecturer = resultArray[2].trim();
				String days = resultArray[3].trim();
				String startTimeStr = resultArray[4].trim();
				String[] startTimeStrSet = startTimeStr.trim().split(":");
				String endTimeStr = resultArray[5].trim();
				String[] endTimeStrSet = endTimeStr.trim().split(":");
				LocalTime startTime = null;
				LocalTime endTime = null;
				int capacity = Integer.parseInt(resultArray[6].trim());

				//try to parse String into integers and create LocalTime objects
				try {
					int starthour = Integer.parseInt(startTimeStrSet[0].trim());  
					int startminute = Integer.parseInt(startTimeStrSet[1].trim());
					int endhour = Integer.parseInt(endTimeStrSet[0].trim()); 
					int endminute = Integer.parseInt(endTimeStrSet[1].trim()); 
					startTime = LocalTime.of(starthour, startminute);
					endTime = LocalTime.of(endhour, endminute);

				} catch (NumberFormatException e) {
					//print default exception message
					System.out.println("can't parse value: " + e.getMessage());
				}

				//build up course object
				Course courseObj = new Course(courseID, courseName, lecturer, days, startTime, endTime, capacity);//fixed capacity 

				//if map doesn't already have the courseID as a key
				if (!allCourses.containsKey(courseID)) {

					//put courseID in map as key with the object courseObj
					allCourses.put(courseID, courseObj);
				} 
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			//no matter what happens, close filereader and bufferedreader
			try {
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return allCourses;	
	}

	/**
	 * Load all the student informations into the DB
	 */
	public HashMap<String, Student> readStudents(String inputFile) {

		HashMap<String, Student> allStudents = new HashMap<String, Student>();

		//create file object
		File file = new File(inputFile);	
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		//create filereader from file
		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);

			String line;

			//read each line in file until we reach the EOF
			while ((line = bufferedReader.readLine()) != null) {

				//split on whitespace (one space or more)
				//gives me array of strings from line
				String[] resultArray = line.trim().split(";");

				int id = 0;
				//try to parse String into integers and create LocalTime objects
				try {
					id = Integer.parseInt(resultArray[0]);  

				} catch (NumberFormatException e) {
					//print default exception message
					System.out.println("can't parse value: " + e.getMessage());
				}

				String name = resultArray[1].trim();
				String username = resultArray[2].trim();
				String password = resultArray[3].trim();
				String transcriptStr = null;

				// Create a hashmap to store the course the student takes and the related score
				HashMap<String, String> transcriptSet = new HashMap<String, String>();

				// If the student enrolled in no course, resultArray.length == 4
				// in this case, transcriptStr == null
				if (resultArray.length == 5) {
					transcriptStr = resultArray[4].trim();
				}

				// If the student do have taken courses,
				// we will separate the couseID and the score and store them in hashmap
				if (transcriptStr != null) {
					String[] transcript = transcriptStr.trim().split(",");

					for (int i = 0; i < transcript.length; i++) {
						String[] courseAndScore = transcript[i].trim().split(":");
						String courseID = courseAndScore[0].trim();
						//We are not sure if the score is available
						//By default, score = null
						String score = null;
						//If the score is available, we store it
						if (courseAndScore.length == 2) {
							score = courseAndScore[1].trim();
						}

						//if map doesn't already have the courseID as a key
						if (!transcriptSet.containsKey(courseID)) {

							//put courseID in map as key with the score
							transcriptSet.put(courseID, score);
						} 
					}
				}			
				Student studentObj = new Student(id, name, username, password, transcriptSet);

				//if map doesn't already have the username(student) as a key
				if (!allStudents.containsKey(username)) {

					//put username(student) in map as key with the object StudentObj
					allStudents.put(username, studentObj);
				} 
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			//no matter what happens, close filereader and bufferedreader
			try {
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return allStudents;	
	}
	

	/**
	 * Load all the professor informations into the DB
	 */
	public HashMap<String, Professor> readProfessors(String inputFile) {

		HashMap<String, Professor> allProfessors = new HashMap<String, Professor>();

		//create file object
		File file = new File(inputFile);	
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		//create filereader from file
		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);

			String line;

			//read each line in file until we reach the EOF
			while ((line = bufferedReader.readLine()) != null) {

				//split on whitespace (one space or more)
				//gives me array of strings from line
				String[] resultArray = line.trim().split(";");
				
				String name = resultArray[0].trim();
				
				int id = 0;
				
				try {
					id = Integer.parseInt(resultArray[1].trim());  

				} catch (NumberFormatException e) {
					//print default exception message
					System.out.println("can't parse value: " + e.getMessage());
				}

				
				String username = resultArray[2].trim();
				String password = resultArray[3].trim();
			
				Professor professorObj = new Professor(id, name, username, password);

				//if map doesn't already have the username(professor) as a key
				if (!allProfessors.containsKey(username)) {

					//put username(student) in map as key with the object professorObj
					allProfessors.put(username, professorObj);
				} 
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			//no matter what happens, close filereader and bufferedreader
			try {
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return allProfessors;	
	}
	
	
	/**
	 * Load all the admin informations into the DB
	 */	
	public HashMap<String, Admin> readAdmin(String inputFile) {

		HashMap<String, Admin> allAdmins = new HashMap<String, Admin>();

		//create file object
		File file = new File(inputFile);	
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		//create filereader from file
		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);

			String line;

			//read each line in file until we reach the EOF
			while ((line = bufferedReader.readLine()) != null) {

				//split on whitespace (one space or more)
				//gives me array of strings from line
				String[] resultArray = line.trim().split(";");
				
				String name = resultArray[1].trim();
				
				int id = 0;
				
				try {
					id = Integer.parseInt(resultArray[0].trim());  

				} catch (NumberFormatException e) {
					//print default exception message
					System.out.println("can't parse value: " + e.getMessage());
				}

				
				String username = resultArray[2].trim();
				String password = resultArray[3].trim();
			
				Admin adminObj = new Admin(id, name, username, password);

				//if map doesn't already have the username(student) as a key
				if (!allAdmins.containsKey(username)) {

					//put username(student) in map as key with the object StudentObj
					allAdmins.put(username, adminObj);
				} 
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			//no matter what happens, close filereader and bufferedreader
			try {
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return allAdmins;	
	}
}
