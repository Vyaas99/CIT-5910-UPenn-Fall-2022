package files;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import courses.Course;
import roles.Admin;
import roles.Professor;
import roles.Student;

class FileInfoReaderTest {
	
	FileInfoReader fileInfoReader = new FileInfoReader();
	
	@BeforeEach
	void setUp() throws Exception {
		
		FileInfoReader fileInfoReader = new FileInfoReader();
	}

	@Test
	void testReadCourses() {
		HashMap<String, Course> coursesDB = fileInfoReader.readCourses("courseInfo.txt");
		
		//Test Case 1
		assertEquals(coursesDB.size(), 50);

		// Print out the values sorted by key
		TreeMap<String, Course> sorted = new TreeMap<>();
		 
        // Copy all data from hashMap into TreeMap
        sorted.putAll(coursesDB);
 
        // Display the TreeMap which is naturally sorted
        for (Entry<String, Course> entry : sorted.entrySet())
            System.out.println(entry.getValue());
        
        System.out.println("\n");
		
	}
	
	@Test
	void testReadStudents() {
		HashMap<String, Student> studentDB = fileInfoReader.readStudents("studentInfo.txt");
		
		//Test Case 1
		assertEquals(studentDB.size(), 2);
		
		//Test Case 2
		assertEquals(studentDB.get("testStudent01").toString(), "StudentName1");
		assertEquals(studentDB.get("testStudent01").getTranscript().toString(), "{CIS191=A, CIS320=A}");
		
		// Print out the values sorted by key
		TreeMap<String, Student> sorted = new TreeMap<>();
		 
        // Copy all data from hashMap into TreeMap
        sorted.putAll(studentDB);
 
        // Display the TreeMap which is naturally sorted
        for (Entry<String, Student> entry : sorted.entrySet())
            System.out.println(entry.getKey() + " " +  entry.getValue());
        
        for (Entry<String, Student> entry : sorted.entrySet())
            System.out.println(entry.getKey() + " " +  entry.getValue().getTranscript());
        
		
	}
	
	@Test
	void testReadProfessors() {
		HashMap<String, Professor> professorDB = fileInfoReader.readProfessors("profInfo.txt");
		

		//Test Case 1
		assertEquals(professorDB.size(), 32);
		
		//Test Case 2
		assertEquals(professorDB.get("Bhusnurmath").toString(), "Arvind Bhusnurmath");
		
		
		// Print out the values sorted by key
		TreeMap<String, Professor> sorted = new TreeMap<>();
		 
        // Copy all data from hashMap into TreeMap
        sorted.putAll(professorDB);
 
        // Display the TreeMap which is naturally sorted
        
        /*
        for (Entry<String, Professor> entry : sorted.entrySet())
            System.out.println("Username: " + entry.getKey() + " -- Name:" + entry.getValue());
        
        System.out.println("\n");
		*/
	}
	
	@Test
	void testReadAdmins() {
		HashMap<String, Admin> adminDB = fileInfoReader.readAdmin("adminInfo.txt");
		

		//Test Case 1
		assertEquals(adminDB.size(), 3);
		
		//Test Case 2
		assertEquals(adminDB.get("admin01").toString(), "admin");
		
		
		// Print out the values sorted by key
		TreeMap<String, Admin> sorted = new TreeMap<>();
		 
        // Copy all data from hashMap into TreeMap
        sorted.putAll(adminDB);
 
        // Display the TreeMap which is naturally sorted
        
        
        for (Entry<String, Admin> entry : sorted.entrySet())
            System.out.println("Username: " + entry.getKey() + " -- Name:" + entry.getValue());
        
        System.out.println("\n");
		
	}

}
