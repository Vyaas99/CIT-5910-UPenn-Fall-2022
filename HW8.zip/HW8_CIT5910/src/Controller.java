import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map.Entry;

import courses.Course;
import files.FileInfoReader;
import roles.Admin;
import roles.Professor;
import roles.Student;
import roles.User;


/**
 * Control the main logic of the Student Management System
 * @author Felix Yuzhou Sun
 */

public class Controller {

	//variables
	/**
	 * All courses' information
	 */
	private HashMap<String, Course> courseDB;

	/**
	 * All students' information
	 */
	private HashMap<String, Student> studentDB;

	/**
	 * All profressor's information
	 */
	private HashMap<String, Professor> professorDB;

	/**
	 * All administrators' information
	 */
	private HashMap<String, Admin> adminDB;



	public static void main(String[] args) {
		//create instance of Controller class
		Controller controller = new Controller(); 
		//call run method, which controls the entire system, through instance of Controller class
		controller.run();
	}

	/**
	 * run method controls the system entirely
	 */
	public void run(){
		// Load all the information with the FileInfoReader
		FileInfoReader fileInfoReader = new FileInfoReader();
		this.courseDB  = fileInfoReader.readCourses("courseInfo.txt");
		this.studentDB = fileInfoReader.readStudents("studentInfo.txt");
		this.professorDB = fileInfoReader.readProfessors("profInfo.txt");
		this.adminDB = fileInfoReader.readAdmin("adminInfo.txt");

		// Create a Scanner object
		Scanner scan = new Scanner(System.in);

		boolean quit = false;
		while (!quit) {
			// Print the main menu of the user interfere
			System.out.println("--------------------------");
			System.out.println("Students Management System");
			System.out.println("--------------------------");
			System.out.println(" 1 -- Login as a student \n"
					+  " 2 -- Login as a professor \n"
					+  " 3 -- Login as an admin \n"
					+  " 4 -- Quit the system \n\n"
					+  "Please enter your option, eg. '1'.");

			// Get the user input for main menu
			int userInput = optionSelection(scan, 1,  4);
			if (userInput == 4) {
				quit = true;
			}

			//Login as a student 
			else if (userInput == 1) {

				boolean student_login = true;
				// Check the user name
				String username = userLogin(scan, studentDB);

				// If the username input is invalid, return to main menu
				if(username == null) {
					student_login = false;
				}
				// Else, continue the login process
				else {
					// Check the password
					int remaining_attempt = 5;
					System.out.println("Please enter your password, or type 'q' to quit.");
					String password = scan.next();
//					if(password.equals("q")) {
//						System.out.println("Returning to main menu");
//						
////					}
					Student student = null;


					while(remaining_attempt > 0) {
						// Quit if the user entered "q"
						if (password.trim().equals("q")) {
							System.out.println("Returning to main menu.\n");
							remaining_attempt = 0;
						}
						// Break the loop if the correct password is entered
						else if (studentDB.get(username).getPassword().equals(password)) {
							student = studentDB.get(username);

							break;
						}
						// Ask the user to make another attempt if the password is wrong
						else {
							System.out.println("Wrong password. Please try again.");
							password = scan.next();//check by entering wrong password
							remaining_attempt -= 1;
						}
						// If the user entered invalid password for 6 consecutive times, return to main menu
						if (remaining_attempt <= 0) {
							System.out.println("Wrong password for too many times. Returning to main menu.\n");
							student_login = false;
						}
					}


					//for adding & deleting courses
					//Add message for success or failed
					ArrayList<Course> courseList = student.getCourseList();

					while(student_login) {
						// Print the welcome info
						System.out.println("--------------------------");
						System.out.println("Welcome, " + student);
						System.out.println("--------------------------");
						System.out.println(" 1 -- View all courses \n"
								+  " 2 -- Add courses to your list \n"
								+  " 3 -- View enrolled courses \n"
								+  " 4 -- drop courses in your list \n"
								+  " 5 -- View grades \n"
								+  " 6 -- Return to previous menu \n"
								+  "Please enter your option, eg. '1'.");

						userInput = optionSelection(scan, 1, 6);





						if (userInput == 6) {
							System.out.println("Returning to main menu...\n");
							student_login = false;
						}

						// Print out the values sorted by key
						else if (userInput == 1) {

							TreeMap<String, Course> sorted = new TreeMap<>();

							// Copy all data from hashMap into TreeMap
							sorted.putAll(courseDB);

							// Display the TreeMap which is naturally sorted
							for (Entry<String, Course> entry : sorted.entrySet())
								System.out.println(entry.getValue());

							//Pause until the user press enter
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						else if(userInput==2) {
							System.out.println("Enter course ID or \"q\" to quit:");
							String courseID=scan.nextLine();
							if(courseID.equals("q")) {
								System.out.println("returning to main menu");
								break;
							}
							int flag=0;
							Course tempCourse = null;


							//TODO add if else 
							//first, if the hashmap contains key "courseID"
							//if returned null, print error message
							//else, return course value


							for(Entry<String,Course> entry:courseDB.entrySet()) {
								if(entry.getKey().equals(courseID)) {
									tempCourse = entry.getValue();
								}
							}
							//if(tempCourse==null) {
							//System.out.println("Course id does not exist");
							if(tempCourse != null) {

								if (courseList.contains(tempCourse)) {
									System.out.println("Failed to add. " + courseID + " is already in your course list.");
									flag = 2;
								}

								else {


									int numDays = tempCourse.getDays().length();
									for (int i = 0;i < courseList.size(); i++) {

										for (int j = 0; j < numDays; j++) {
											for(int k = 0;k < courseList.get(i).getDays().length(); k++) {
												if((tempCourse.getDays().charAt(j)) == courseList.get(i).getDays().charAt(k)) {
													if((tempCourse.getStartTime().getHour() >= courseList.get(i).getStartTime().getHour()&&tempCourse.getEndTime().getHour()<=courseList.get(i).getEndTime().getHour())||(tempCourse.getStartTime().getHour()>=courseList.get(i).getStartTime().getHour()&&tempCourse.getEndTime().getHour()<=courseList.get(i).getEndTime().getHour())||(tempCourse.getStartTime().getHour()<=courseList.get(i).getEndTime().getHour()&&tempCourse.getEndTime().getHour()>=courseList.get(i).getEndTime().getHour())) {
														flag = 1;
													}
												}
											}

										}

									}
								}
							}
							if(flag == 0) {
								for(Entry<String,Course> entry1:courseDB.entrySet()) {
									if(entry1.getKey().equals(courseID)) {
										student.addCourse(entry1.getValue());
										System.out.println("Added " + courseID + " successfully.");
									}
								}
							}

							if(tempCourse==null) {
								System.out.println("Course does not exist.");
							}
							else if (flag == 1){
								System.out.println("Failed to add. Time conflict can be a possible reason.");
							}

							System.out.println("\n Press enter to return to the previous menu.\n");

							try {
								System.in.read();
							} 
							catch (IOException e) {
								e.printStackTrace();
							}

						}
						else if(userInput==3) {
							//Print the current enrolled course list
							if (student.getCourseList().size() == 0) {
								System.out.println("You haven't enrolled in any courses yet.");
							}
							else {
								for (int i = 0; i < student.getCourseList().size(); i++) 
								{
									System.out.println(student.getCourseList().get(i).getCourseID());
								}
							}
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} 
							catch (IOException e) {
								e.printStackTrace();
							}
						}
						else if(userInput==4) {
							System.out.println("Enter the course id or \"q\" to quit::");
							String courseID=scan.nextLine();
							if(courseID.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}
							for(int i=0;i<courseList.size();i++) {
								if(courseList.get(i).getCourseID().equals(courseID)) {
									courseList.remove(i);
									System.out.println("Course removed successfully.");
								}
								else {
									System.out.println("Course does not exist.");
								}
							}
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} 
							catch (IOException e) {
								e.printStackTrace();
							}
						}
						else if(userInput==5) {
							System.out.println("Here are the courses you already taken, with your grade in a letter format.");
							int counter = 0;
							//System.out.println(student.getTranscript().toString());
							for(Entry<String,String> entryT:student.getTranscript().entrySet()) {
								if(entryT.getValue() != null) {
									String courseScore = entryT.getValue();
									String courseIDinT = entryT.getKey();
									String courseName = courseDB.get(courseIDinT).getCourseName();
									System.out.println("Grade of " + courseIDinT + " " + courseName + ": " + courseScore);
									counter++;

								}
							}
							if (counter == 0) {
								System.out.println("\nYou haven't finished any courses till now.");
							}
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} 
							catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}

			}

			//Login as a professor 
			else if (userInput == 2) {

				//TODO
				//Use a tree map to print all the courses the professor provides
				/*
				 * TreeMap<String, Course> sorted = new TreeMap<>();

					        // Copy all data from hashMap into TreeMap
					        sorted.putAll(courseDB);

					        // Display the TreeMap which is naturally sorted
					        for (Entry<String, Course> entry : sorted.entrySet())
					            System.out.println(entry.getValue());
				 */

				boolean professor_login = true;
				// Check the user name
				String username = userLogin(scan, professorDB);

				// If the username input is invalid, return to main menu
				if(username == null) {
					professor_login = false;
				}
				// Else, continue the login process
				else {
					// Check the password
					int remaining_attempt = 5;
					System.out.println("Please enter your password, or type 'q' to quit.");
					String password = scan.next();
					if(password.trim().equals("q")) {
						System.out.println("Returning to main menu.\n");
						break;
					}
					Professor professor = null;


					while(remaining_attempt > 0) {
						// Quit if the user entered "q"
						if (password.trim().equals("q")) {
							System.out.println("Returning to main menu.\n");
							remaining_attempt = 0;
						}
						// Break the loop if the correct password is entered
						else if (professorDB.get(username).getPassword().equals(password)) {
							professor = professorDB.get(username);

							break;
						}
						// Ask the user to make another attempt if the password is wrong
						else {
							System.out.println("Wrong password. Please try again.");
							password = scan.next();
							remaining_attempt -= 1;
						}
						// If the user entered invalid password for 6 consecutive times, return to main menu
						if (remaining_attempt <= 0) {
							System.out.println("Wrong password for too many times. Returning to main menu.\n");
							professor_login = false;
						}
					}

					while(professor_login) {
						// Print the welcome info
						System.out.println("--------------------------");
						System.out.println("Welcome, " + professor);
						System.out.println("--------------------------");
						System.out.println(" 1 -- View given courses \n"
								+  " 2 -- View student list of the given course\n"
								+  " 3 -- Return to the previous menu \n"
								+  "Please enter your option, eg. '1'.");

						userInput = optionSelection(scan, 1, 6);

						if (userInput == 3) {
							System.out.println("Returning to main menu...\n");
							professor_login = false;
						}
						else if(userInput==1) {
							TreeMap<String,Course> sortedProf = new TreeMap<>();

							// Copy all data from hashMap into TreeMap
							sortedProf.putAll(courseDB);

							// Display the TreeMap which is naturally sorted
							for(Entry<String,Course> entry1:sortedProf.entrySet()){
								if(professor.getName().equals(entry1.getValue().getLecturer())) {
									professor.getCourses().add(entry1.getValue());
								}
							}
							for(int i=0;i<professor.getCourses().size();i++) {
								System.out.println(professor.getCourses().get(i).toString());
							}
							//							System.out.println(professor.getCourses().toString());
						}
						else if(userInput==2) {
							for(Entry<String,Student> entry2:studentDB.entrySet()) {
								for(int i=0;i<entry2.getValue().getCourseList().size();i++) {
									if(professor.getName().equals(entry2.getValue().getCourseList().get(i).getLecturer())) {
										professor.getStudentList().add(entry2.getValue());
									}
								}
							}
							System.out.println(professor.getStudentList().toString());
						}

					}
				}

			}


			//Login as an admin 

			else if (userInput == 3) {

				boolean admin_login = true;
				// Check the user name
				String username = userLogin(scan, adminDB);

				// If the username input is invalid, return to main menu
				if(username == null) {
					admin_login = false;
				}
				// Else, continue the login process
				else {
					// Check the password
					int remaining_attempt = 5;
					System.out.println("Please enter your password:");//, or type 'q' to quit.");
					String password = scan.next();
//					if(password.trim().equals("q")) {
//						System.out.println("Returning to main menu.\n");
//						break;
//					}
					Admin admin = null;


					while(remaining_attempt > 0) {
						// Quit if the user entered "q"
						if (password.trim().equals("q")) {
							System.out.println("Returning to main menu.\n");
							remaining_attempt = 0;
						}
						// Break the loop if the correct password is entered
						else if (adminDB.get(username).getPassword().equals(password)) {
							admin = adminDB.get(username);

							break;
						}
						// Ask the user to make another attempt if the password is wrong
						else {
							System.out.println("Wrong password. Please try again.");
							password = scan.next();
							remaining_attempt -= 1;
						}
						// If the user entered invalid password for 6 consecutive times, return to main menu
						if (remaining_attempt <= 0) {
							System.out.println("Wrong password for too many times. Returning to main menu.\n");
							admin_login = false;
						}
					}

					while(admin_login) {
						// Print the welcome info
						System.out.println("--------------------------");
						System.out.println("Welcome, " + admin);
						System.out.println("--------------------------");
						System.out.println(" 1 -- View all courses \n"
								+  " 2 -- Add new courses \n"
								+  " 3 -- Delete courses \n"
								+  " 4 -- Add new professor \n"
								+  " 5 -- Delete professor \n"
								+  " 6 -- Add new student \n"
								+  " 7 -- Delete student \n"
								+  " 8 -- Return to the previous menu \n"
								+  "Please enter your option, eg. '1'.");

						userInput = optionSelection(scan, 1, 8);

						if (userInput == 8) {
							System.out.println("Returning to main menu...\n");
							admin_login = false;
						}
						else if (userInput == 1) {

							TreeMap<String, Course> sorted = new TreeMap<>();

							// Copy all data from hashMap into TreeMap
							sorted.putAll(courseDB);

							// Display the TreeMap which is naturally sorted
							for (Entry<String, Course> entry : sorted.entrySet())
								System.out.println(entry.getValue());

							//Pause until the user press enter
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						else if(userInput==2) {
							boolean repeat = true;
							String courseID = null;
							while (repeat) {


								System.out.println("Enter course ID or type \"q\" to quit:");
								
								courseID = scan.nextLine().trim();
								if(password.equals("q")) {
									System.out.println("Returning to main menu.\n");
									break;
								}
								if (courseDB.containsKey(courseID)) {
									System.out.println("The course ID already exists. Please try another one.");
								}
								else {repeat = false;}
							}
							
							System.out.println("Enter course name or type \"q\" to quit: ");
							String courseName = scan.nextLine().trim();
							if(courseName.equals("q")) {
								System.out.println("Returning to main menu.\n");
								break;
							}
							
							System.out.println("Enter lecturer or type \"q\" to quit: ");
							String lecturer = scan.nextLine().trim();
							if(lecturer.equals("q")) {
								System.out.println("Returning to main menu.\n");
								break;
							}
							
							System.out.println("Enter days or type \"q\" to quit:");
							String days = scan.nextLine().trim();
							if(days.equals("q")) {
								System.out.println("Returning to main menu.\n");
								break;
							}
							repeat = true;
							String startTime = null;
							LocalTime st=null;
							while (repeat) {

								try {
									System.out.println("Enter start time or \"q\" to quit:");
									startTime = scan.nextLine();
									if(startTime.equals("q")) {
										System.out.println("Returning to main menu");
										break;
									}
									st=LocalTime.parse(startTime);
//									scan.nextLine();
								}

								//Prompts again if the user input is not a valid integer, 
								catch (Exception e) 
								{
									scan.next();
									System.out.println("Please enter a valid time.");
								}

//								if (startHour < 0 || startHour > 23) {
//									System.out.println("Please enter a number between 0 to 23.");				
//								}
//								else {
//									repeat = false;
//								}
								repeat=false;
							}
							
							repeat = true;
							String endTime = null;
							LocalTime et=null;
							while (repeat) {

								try {
									System.out.println("Enter end time or \"q\" to quit:");
									endTime = scan.nextLine();
									if(endTime.equals("q")) {
										System.out.println("Returning to main menu");
										break;
									}
									et=LocalTime.parse(endTime);
//									scan.nextLine();
								}

								//Prompts again if the user input is not a valid integer, 
								catch (Exception e) 
								{
									scan.next();
									System.out.println("Please enter a valid time.");
								}

//								if (startHour < 0 || startHour > 23) {
//									System.out.println("Please enter a number between 0 to 23.");				
//								}
//								else {
//									repeat = false;
//								}
								repeat=false;
							}
							
//							repeat = true;
//							int startHour = 0;
//							while (repeat) {
//
//								try {
//									System.out.println("Enter start hour (between 0 and 23):");
//									startHour = scan.nextInt();
//									scan.nextLine();
//								}
//
//								//Prompts again if the user input is not a valid integer, 
//								catch (Exception e) 
//								{
//									scan.next();
//									System.out.println("Please enter an valid number.");
//								}
//
//								if (startHour < 0 || startHour > 23) {
//									System.out.println("Please enter a number between 0 to 23.");				
//								}
//								else {
//									repeat = false;
//								}
//							}
//						
//							repeat = true;
//							int startMinute = 0;
//							while (repeat) {
//
//								try {
//									System.out.println("Enter start minute (between 0 and 59):");
//									startMinute = scan.nextInt();
//									scan.nextLine();
//								}
//
//								//Prompts again if the user input is not a valid integer, 
//								catch (Exception e) 
//								{
//									scan.next();
//									System.out.println("Please enter an valid number.");
//								}
//
//								if (startMinute < 0 || startMinute > 59) {
//									System.out.println("Please enter a number between 0 to 59.");				
//								}
//								else {
//									repeat = false;
//								}
//							}
//							
//							repeat = true;
//							int endHour = 0;
//							while (repeat) {
//
//								try {
//									System.out.println("Enter end hour (between 0 and 23):");
//									endHour = scan.nextInt();
//									scan.nextLine();
//								}
//
//								//Prompts again if the user input is not a valid integer, 
//								catch (Exception e) 
//								{
//									scan.next();
//									System.out.println("Please enter an valid number.");
//								}
//
//								if (endHour < 0 || endHour > 23) {
//									System.out.println("Please enter a number between 0 to 23.");				
//								}
//								else if (endHour < startHour) {
//									System.out.println("End time cannot be ealier than the start time");
//								}
//								else {
//									repeat = false;
//								}
//							}
//							
//						
//							
//							repeat = true;
//							int endMinute = 0;
//							while (repeat) {
//
//								try {
//									System.out.println("Enter end minute (between 0 and 59):");
//									endMinute = scan.nextInt();
//									scan.nextLine();
//								}
//
//								//Prompts again if the user input is not a valid integer, 
//								catch (Exception e) 
//								{
//									scan.next();
//									System.out.println("Please enter an valid number.");
//								}
//
//								if (endMinute < 0 || endMinute > 59) {
//									System.out.println("Please enter a number between 0 to 59.");				
//								}
//								else if  (endHour == startHour && endMinute <= startMinute) {
//									System.out.println("End time cannot be ealier than the start time");
//								}
//								else {
//									repeat = false;
//								}
//							}
//	
//							LocalTime startTime=LocalTime.of(startHour,startMinute);
//							LocalTime endTime=LocalTime.of(endHour,endMinute);
		
							
							int capacity = 0;
							repeat = true;
							while (repeat) {

								try {
									System.out.println("Enter the capacity of the class or enter \"q\" to quit:");
									String stringCapacity = scan.nextLine();
									if(stringCapacity.equals("q")) {
										System.out.println("Returning to main menu");
										break;
									}
									else {
										capacity=Integer.parseInt(stringCapacity);
									}
//									scan.nextLine();
								}

								//Prompts again if the user input is not a valid integer, 
								catch (Exception e) 
								{
									scan.next();
									System.out.println("Please enter an valid number.");
								}

								if (capacity < 0) {
									System.out.println("Please enter a positive number");				
								}
								else {
									repeat = false;
								}
							}
							
							
							Course courseObj = new Course(courseID, courseName, lecturer, days, st, et, capacity);
							//courseDB.put(courseID,courseObj);
							if (!courseDB.containsKey(courseID)) {

								//put courseID in map as key with the object courseObj
								courseDB.put(courseID, courseObj);
								System.out.print("The course was added successfully.");
							}
							
							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} catch (IOException e) {
								e.printStackTrace();
							}
							
						}
						
						
						
						
						else if(userInput==3) {
							System.out.println("Enter course id or \"q\" to quit:");
							String courseID=scan.nextLine();
							if(courseID.equals("q")) {
								System.out.println("returning to main menu");
								break;
							}
							if (courseDB.containsKey(courseID)) {
								courseDB.remove(courseID);
								System.out.println("Successful deleted " + courseID + " from the system.");
							} 
							else {
								System.out.println("Course id does not exist.\n");
							}

							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} 
							catch (IOException e) {
								e.printStackTrace();
							}

						}
						else if(userInput==4) {
							HashSet<Integer> idSet = new HashSet<Integer>();
							for (Entry<String, Professor> entryP : professorDB.entrySet()) {
								idSet.add(entryP.getValue().getId());
							}



							int id =0;
							boolean repeat = true;
							while (repeat) {
								System.out.println("Enter id or \"q\" to quit:");
								try {
									String stringId = scan.nextLine().trim();
									if(stringId.equals("q")) {
										System.out.println("Returning to main menu");
										break;
									}
									else {
										id=Integer.parseInt(stringId);
									}
//									scan.nextLine();
								}

								//Prompts again if the user input is not a valid integer, 
								catch (Exception e) 
								{
									scan.next();
									System.out.println("Please enter an valid number.");


								}

								if (idSet.contains(id)) {
									System.out.println("The id already exists.");		

								} 
								else {repeat = false;}
							}

							System.out.println("Enter name or \"q\" to quit:");

							String name = scan.nextLine().trim();
							if(name.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}


							String username1 = null;
							repeat = true;

							while (repeat) {

								System.out.println("Enter username or \"q\" to quit:");
								username1 = scan.nextLine().trim();
								if(username1.equals("q")) {
									System.out.println("Returning to main menu");
									break;
								}

								if (professorDB.containsKey(username1)) {
									System.out.println("User name already exists. Please try another one.");
								}

								else {
									repeat = false;
								}
							}

							System.out.println("Enter password or \"q\" to quit:");
							String password1=scan.nextLine();
							if(password1.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}
							Professor prof = new Professor(id,name,username1,password1);
							if(!(professorDB.containsKey(username1))) {
								professorDB.put(username1, prof);
								System.out.println("Professor is successfully added");
							}
							else {
								System.out.println("Username already exists. Enter another username.");
							}
							//System.out.println(professorDB.toString());
						}
						else if(userInput==5) {
							System.out.println("Enter username or \"q\" to quit:");
							username=scan.nextLine();
							if(username.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}
							if(professorDB.containsKey(username)) {
								professorDB.remove(username);
								System.out.println("Professor successfully removed");
							}
							else {
								System.out.println("Professor with the username of "+username+" does not exist.");
							}

							//TODO
							//message
							//The professr "name" is successful delete or not


							System.out.println(professorDB.toString());
						}
						else if(userInput==6) {
							HashSet<Integer> idSet = new HashSet<Integer>();
							for (Entry<String, Student> entryP : studentDB.entrySet()) {
								idSet.add(entryP.getValue().getId());
							}

							int id =0;
							boolean repeat = true;
							while (repeat) {
								System.out.println("Enter id or \"q\" to quit:");
								try {
									

									String stringId = scan.nextLine();
//									scan.nextLine();
									if(stringId.equals("q")) {
										System.out.println("Returning to main menu");
										break;
									}
									else {
										id=Integer.parseInt(stringId);
									}
									
								}

								//Prompts again if the user input is not a valid integer, 
								catch (Exception e) 
								{
									scan.next();
									System.out.println("Please enter an valid number.");
								}

								if (idSet.contains(id)) {
									System.out.println("The id already exists.");				
								}
								else {
									repeat = false;
								}
							}

							System.out.println("Enter name or \"q\" to quit:");

							String name = scan.nextLine().trim();
							if(name.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}


							String username1 = null;
							repeat = true;

							while (repeat) {

								System.out.println("Enter username or \"q\" to quit:");
								username1 = scan.nextLine().trim();
								if(name.equals("q")) {
									System.out.println("Returning to main menu");
									break;
								}

								if (studentDB.containsKey(username1)) {
									System.out.println("Username already exists. Please try another one.");
								}

								else {
									repeat = false;
								}
							}

							System.out.println("Enter password or \"q\" to quit:");
							String password1=scan.nextLine().trim();
							if(name.equals("q")) {
								System.out.println("Returning to main menu");
								break;
							}




							HashMap<String, String> transcript=new HashMap<String, String>();
							boolean stop = false;
							String courseID=null;
							String grade=null;
							while(stop == false) {


								System.out.println("Please enter ID of a course which this student already took, one in a time\n"
										+ "Type \'q\' to quit, type \'n\' to stop adding.");

								courseID = scan.nextLine().trim();
								if(courseID.equals("q")) {
									System.out.println("Returning to main menu");
									break;
								}
								if (courseID.equals("n")) {
									stop = true;
								}

								else if (!courseDB.containsKey(courseID)) {
									System.out.print("Course ID does't not exist, please try another one.");
								}
								else {

									System.out.println("Enter grade or \"q\" to quit:");
									grade = scan.nextLine();
									if(grade.equals("q")) {
										System.out.println("returning to main menu");
										break;
									}
									transcript.put(courseID, grade);//added suppress warning null to run()
									if (grade.equals("n")) {
										stop = true;
									}
								}
							}
							if(courseID.equals("q")) {
								break;
							}
							if(grade.equals("q")) {
								break;
							}

							Student student01=new Student(id,name,username1,password1,transcript);
							if(!studentDB.containsKey(username1)) {
								studentDB.put(username1, student01);
								System.out.println("Student successfully added.");
							}
							else {
								System.out.println("Username already exists");
							}
							//System.out.println(studentDB.toString());
							//Pause until the user press enter

							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} catch (IOException e) {
								e.printStackTrace();
							}

						}
						else if(userInput==7) {
							System.out.println("Enter username or \"q\" to quit:");
							username=scan.nextLine();
							if(username.equals("q")) {
								System.out.println("returning to main menu");
								break;
							}
							if(studentDB.containsKey(username)) {
								studentDB.remove(username);
								System.out.println("Student successfully removed.");
							}
							else {
								System.out.println("Username not found.");
							}
							//System.out.println(studentDB.toString());
							//Pause until the user press enter

							System.out.println("\n Press enter to return to the previous menu.\n");
							try {
								System.in.read();
							} catch (IOException e) {
								e.printStackTrace();
							}

						}

					}
				}
			}
		}

		System.out.println("Quiting the system... Goodbye.");
		scan.close();

	}

	/**
	 * Get the user input for selecting menu options
	 * @param scanner the scanner
	 * @param start smallest integer option
	 * @param end largest integer option
	 * @return
	 */
	public int optionSelection(Scanner scanner, int start, int end) {

		int input = 0;
		boolean repeat = true;
		while (repeat) {			
			try {
				repeat = false;
				input = scanner.nextInt();
				scanner.nextLine();//added to consume

				//Prompts again if the number is not within range
				if (input < start || input > end) {
					System.out.printf("Please enter an valid number.\nThe number should be between %d - %d.\n", start, end);
					repeat = true;
				}
			}

			//Prompts again if the user input is not a valid integer, 
			catch (Exception e) 
			{
				scanner.next();
				repeat = true;
				System.out.println("Please enter an valid number.");
			}
		}

		return input;	
	}

	/**
	 * Check the username and password for login process. Return the valid username if the username
	 * and its related password are correct. Return null if username or password is invalid.
	 * @param scan the scanner
	 * @param map the database for all user info of that type
	 * @param usernameIn
	 * @return
	 */
	public String userLogin(Scanner scan, HashMap userDB) {
		// Initialize the local variables
		String username_Login = null;
		int remaining_attempt = 5;
		// Print the directions and take user input
		System.out.println("Please enter your username, or type 'q' to quit.");
		String usernameIn = scan.next();

		while(remaining_attempt > 0) {
			// Quit if the user entered "q"
			if (usernameIn.trim().equals("q")) {
				System.out.println("Returning to main menu.\n");
				return null;
			}
			// Break the loop if a valid username is entered
			else if (userDB.containsKey(usernameIn)) {
				username_Login = usernameIn;
				break;
			}
			// Ask the user to make another attempt if the input is invalid
			else {
				System.out.println("Username not found. Please try again.");
				usernameIn = scan.next();
				remaining_attempt -= 1;
			}
		}
		// If the user entered invalid username for 6 consecutive times, return null
		if (remaining_attempt <= 0) {
			System.out.println("Log in failed for too many times. Returning to main menu.");
			return null;
		}

		return username_Login;

	}

}
