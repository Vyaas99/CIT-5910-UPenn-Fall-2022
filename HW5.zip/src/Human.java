import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Represents a human player.
 *
 */
public class Human {
	
	/**
	 * Human player's hand.
	 */
	String[] handCards;
	
	/**
	 * Access to main pile and discard pile.
	 */
	Cards cards;
	
	/**
	 * Creates a human player.
	 * Gives access to the main pile and discard pile via given instance of Cards class.
	 * @param cards for access to main pile and discard pile
	 */
	public Human(Cards cards) {
		this.cards = cards;
	}
	
	/**
	 * Sets human player's hand.
	 * @param handCards to set
	 */
	public void setHandCards(String[] handCards) {
		
		//TODO Add your code here
		this.handCards=handCards;
	}
	
	/**
	 * Gets human player's hand.
	 * @return human player's hand
	 */
	public String[] getHandCards() {
		
		//TODO Add your code here
		return this.handCards;
	}
	
	/**
	 * Controls the game play for the human.
	 * @param scanner to use for user input
	 */
	public void play(Scanner scanner) {
		
		//TODO Add your code here
		System.out.println("Human Hand Cards:");//prints human cards
		System.out.print("[");
	    for(int i=0;i<getHandCards().length;i++) {
	    	if(i!=getHandCards().length-1) {
	    		System.out.print(getHandCards()[i]+",");
	    	}
	    	else {
	    		System.out.print(getHandCards()[i]);
	    	}
	    		    
	    }
	    System.out.print("]");
    	System.out.println("");
		System.out.println("You can take "+this.cards.discardPile[0]+" from the discard pile or reveal the card from the main pile.");
		System.out.println("Reply d or m to respond.");//prompts response for discard top card
		String response=scanner.nextLine();
		if(response.equals("m")) {
			String m=this.cards.getFirstFromMainPileAndRemove();
			System.out.println("The letter from the main pile is "+m+".");
			String prompt="Do you want to accept this letter?";
			boolean yesOrNo=askYesOrNo(prompt,scanner);
			if(yesOrNo) {
				int i=askForTheLetterToBeReplaced(this.handCards.length,scanner);
				System.out.println("You have chosen to replace "+this.handCards[i]+" with "+m+".");
				this.handCards[i]=m;//replaces hand card with top card of main pile
				System.out.print("[");//prints hand cards
			    for(int i1=0;i1<getHandCards().length;i1++) {
			    	if(i1!=getHandCards().length-1) {
			    		System.out.print(getHandCards()[i1]+",");
			    	}
			    	else {
			    		System.out.print(getHandCards()[i1]);
			    	}
			    		    
			    }
			    System.out.print("]");
		    	System.out.println("");
			}
			else {
				this.cards.addToDiscardPile(m);
			}
		}
		else if(response.equals("d")) {
			String d=this.cards.discardPile[0];//places top card from discard pile to hand cards.
			int i=askForTheLetterToBeReplaced(this.handCards.length,scanner);
			System.out.println("You have chosen to replace "+this.handCards[i]+" with "+d+".");
			this.handCards[i]=d;
			System.out.print("[");
		    for(int i1=0;i1<getHandCards().length;i1++) {
		    	if(i1!=getHandCards().length-1) {
		    		System.out.print(getHandCards()[i1]+",");
		    	}
		    	else {
		    		System.out.print(getHandCards()[i1]);
		    	}
		    		    
		    }
		    System.out.print("]");
	    	System.out.println("");
			
		}
		else {
			System.out.println("Choose properly.");
			play(scanner);
		}
		
		
		
		
	}
	
	/**
	 * Displays (prints) the given msg and uses the given scanner to get user input 
	 * of a response.
	 * The expected response is yes/y or no/n.
	 * Prompts again if the response is invalid.
	 * @param msg to be displayed
	 * @return true if user answers yes/y, or false if user answers no/n
	 */
	public boolean askYesOrNo(String msg, Scanner scanner) {
		
		//TODO Add your code here
		System.out.println(msg);
		try {
			String yesOrNoString=scanner.nextLine();//Scans for user input.
			yesOrNoString=yesOrNoString.toLowerCase();//Converts the user input to lowercase.
			String strippedString=yesOrNoString.strip();//Strips the updated user input's leading and trailing spaces.
			boolean yesOrNo=strippedString.startsWith("y");//Checks if the updated user input starts with "y."
			return yesOrNo;
		}
		catch(InputMismatchException e) {//Catches input mismatch error.
			boolean yesOrno=askYesOrNo(msg,scanner);//Prompts the same question again till we get a valid input.
			return yesOrno;
		}
	}
	
	/**
	 * Asks the index of letter the user wants to replace.
	 * Prompts again if the input index is invalid or out of index range.
	 * @param length the valid index range should be in 0 to given length
	 * @param scanner to be used for user input
	 * @return the index of the letter to be replaced
	 */
	public int askForTheLetterToBeReplaced(int length, Scanner scanner) {
	    
		//TODO Add your code here
		System.out.println("Enter the index of the letter you want to replace:");
		int index=0;
		try {
			index=scanner.nextInt();
			scanner.nextLine();//consumes line
		}
		catch(InputMismatchException e) {
			System.out.println("Enter an integer.");//calls again in case of error
			askForTheLetterToBeReplaced(length,scanner);
		}
		if(index<0&&index>=length) {
			System.out.println("Index out of bounds. Try again.");//calls again if out of bounds of question
			askForTheLetterToBeReplaced(length,scanner);
		}
		return index;
	}
	
}
