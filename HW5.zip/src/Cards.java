import java.util.Random;

/**
 * Creates and manages a main pile of cards and a discard pile of cards.
 *
 */
public class Cards {

	/**
	 * Main pile of cards. 
	 */
	String[] mainPile;
	
	/**
	 * Discard pile of cards.
	 */
	String[] discardPile;
	
	/**
	 * Creates instance of Cards class.
	 */
	public Cards() {
		
	}
	
	/**
	 * Sets up main pile, which is an array containing the letters of the alphabet * length.
	 * @param length of the words
	 * @return main pile
	 */
	public String[] setUpMain(int length) {
	   
		//TODO Add your code here
		String stringAlphabet="a b c d e f g h i j k l m n o p q r s t u v w x y z";
		String[] alphabet=stringAlphabet.split(" ");//Creating string array from string
		String[] result=new String[length*alphabet.length];
		int k=0;
		//Looping based on length
		for(int i=0;i<length;i++) {
			for(int j=0;j<alphabet.length;j++) {//Looping based on the english alphabet
				result[k]=alphabet[j];
				k++;
			}
		}
		this.mainPile=result;//setting result to main pile
		return result;
	}
	
	/**
	 * Sets up discard pile, which is an empty array.
	 * @return discard pile
	 */
	public String[] setUpDiscard() {
		   
		//TODO Add your code here		
		String[] discard_pile= new String[1];//setting up by creating a discard pile of default size one.
		this.discardPile=discard_pile;
		return discard_pile;
	}
	
	/**
	 * Gets the main pile.
	 * @return main pile
	 */
	public String[] getMainPile() {
		
		//TODO Add your code here
		return this.mainPile;
		
	}
	
	/**
	 * Gets the discard pile.
	 * @return discard pile
	 */
	public String[] getDiscardPile() {
		
		//TODO Add your code here
		return this.discardPile;
	}
	
	/**
	 * Shuffles cards in the main pile.
	 */
	public void shuffleMainCards() {
		
		//TODO Add your code here
		Random random=new Random();
		for(int i=0;i<this.mainPile.length;i++) {
			int index1=random.nextInt(this.mainPile.length);//getting two random indices.
	        int index2=random.nextInt(this.mainPile.length);
	        String temp1=this.mainPile[index1];//assigning values at random to temp variable
	        String temp2=this.mainPile[index2];
	        this.mainPile[index1]=temp2;
	        this.mainPile[index2]=temp1;//shuffling the letters in the pile by exchanging.
		}
		
	}
	
	/**
	 * Shuffles cards in the discard pile.
	 */
	public void shuffleDiscardCards() {
		
		//TODO Add your code here
		Random random=new Random();//same method as shuffling main pile
		for(int i=0;i<this.discardPile.length;i++) {
			int index1=random.nextInt(this.discardPile.length);
	        int index2=random.nextInt(this.discardPile.length);
	        String temp1=this.discardPile[index1];
	        String temp2=this.discardPile[index2];
	        this.discardPile[index1]=temp2;
	        this.discardPile[index2]=temp1;
		}
	}
	
	/**
	 * Deals two hands of length cards each to the given computer player 
	 * and to the given human player. Deals cards from the main pile.
	 * The computer is always the first person that gets dealt.
	 * Removes the card on top of the main pile and put it on the discard pile.
	 * @param computer computer player
	 * @param human human player
	 * @param length of the hand cards
	 */
	public void dealInitialCards(Computer computer, Human human, int length) {

		//TODO Add your code here
		String[] computerHand= new String[length];//initializing size of hands absed on length
		String[] humanHand= new String[length];
		for(int i=0;i<length;i++) {//running a loop to deal one by one
			computerHand[i]=getFirstFromMainPileAndRemove();
			humanHand[i]=getFirstFromMainPileAndRemove();
		}
		this.discardPile[0]=getFirstFromMainPileAndRemove();//adding to discard pile.
		computer.setHandCards(computerHand);
		human.setHandCards(humanHand);
	}
	
	/**
	 * Checks whether the main pile is empty.
	 * If so, shuffles the discard pile and moves all the cards to the main pile.
	 * Then turns over the top card of the main pile to be the start of the new discard pile.
	 * Otherwise, does nothing.
	*/
	public void checkCards() {
	    
		//TODO Add your code here
		if(this.mainPile[0]==null) {//if main pile is empty
			shuffleDiscardCards();//shuffles discard pile
			this.mainPile=this.discardPile;	//and assigns to main pile
			this.discardPile[0]=getFirstFromMainPileAndRemove();//top card of main pile to discard pile
		}
	}
	
	/**
	 * Returns and removes the first card of the main pile.
	 * @return the first card of the main pile
	 */
	public String getFirstFromMainPileAndRemove() {
		
		//TODO Add your code here
		String top1=this.mainPile[0];//stores to card in main pile to a temp variable
		String[] temp=new String[this.mainPile.length-1];//creates temp array with one size less.
		for(int i=1;i<this.mainPile.length;i++) {//loops from second card
			temp[i-1]=this.mainPile[i];//assigns to previous index position in temp array
		}
		this.mainPile=temp;//assigns temp to main pile
		return top1;//returns the initial top card of main pile.
	}
	
	/**
	 * Returns and removes the first card of the discard pile.
	 * @return the first card of the discard pile
	 */
	public String getFirstFromDiscardPileAndRemove() {
		
		//TODO Add your code here
		String top1=this.discardPile[0];//same as main pile.
		String[] temp=new String[this.discardPile.length-1];
		for(int i=1;i<this.discardPile.length;i++) {
			temp[i-1]=this.discardPile[i];
		}
		this.discardPile=temp;
		return top1;
	}
	
	/**
	 *  Adds given card to top of the discard pile.
	 * @param card to add to top of discard pile
	 */
	public void addToDiscardPile(String card) {
		
		//TODO Add your code here
		String[] temp=new String[this.discardPile.length+1];//same as removing and adding but wont return top card but instead adds to the top.
		temp[0]=card;//temp array is one size higher and the top card is assigned
		for(int i=1;i<this.discardPile.length;i++) {
			temp[i]=this.discardPile[i-1];
		}
		this.discardPile=temp;
	}
}
