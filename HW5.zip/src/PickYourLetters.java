import java.util.InputMismatchException;
import java.util.Scanner;

import files.WordProcessor;
import files.WordReader;

/**
 * In this HW, we will be implementing the game Pick Your Letters, which is a game that involves 
 * re-arranging a group of cards in order to make up a word.
 * 
 * About the Game
 * This game needs two players and we will just play the user versus the computer. 
 * The user’s moves are decided by the user playing the game, by asking for input, and the computer’s 
 * moves are decided by the program.
 */
public class PickYourLetters {
	
	public static void main(String[] args) {
		
		PickYourLetters pyl = new PickYourLetters();
		pyl.run();
	}
	
	/**
	 * Launches and controls the game.
	 */
	public void run() {
		
		System.out.println("Welcome to the game!");
		
		//reads all words from file
		WordReader wr = new WordReader();
		String[] allWords = wr.readFromFile("words.txt");

		//create scanner for user input
		Scanner scanner = new Scanner(System.in);		

		//ask for a number as the length of the word
		//TODO Add your code here
		int l=askForLength(scanner);

		//create WordProcessor
		WordProcessor wp=new WordProcessor();
		//filter allWords with a length equal to the given length
		//TODO Add your code here
		allWords=wp.filterWordList(allWords, l);
		System.out.println("All words:"+allWords.length);
		
		//create Cards
		Cards cards= new Cards();
		//set up mainPile and discardPile
		//TODO Add your code here
		cards.setUpMain(l);
		cards.setUpDiscard();
	    
	    //shuffle main pile
		cards.shuffleMainCards();
		//TODO Add your code here
	    
	    //create computer player and human player
		Computer computer = new Computer(cards);
		Human human= new Human(cards);
	    //deal cards to players and initialize discard pile
		cards.dealInitialCards(computer, human, l);
		//TODO Add your code here
	    System.out.println("Computer Hand:");
	    System.out.print("[");
	    for(int i=0;i<computer.getHandCards().length;i++) {
	    	if(i!=computer.getHandCards().length-1) {
	    		System.out.print(computer.getHandCards()[i]+",");
	    	}
	    	else {
	    		System.out.print(computer.getHandCards()[i]);
	    	}
	    		    
	    }
	    System.out.print("]");
    	System.out.println("");
	    //set up a target word list for computer strategy
		//TODO Add your code here
		//String[] target_array=computer.targetArray(computer.getHandCards(),allWords.length,allWords);
	    String[] target_array=computer.targetArray(computer.getHandCards(),l,allWords);
	    System.out.println("-----------------------------------------------");
	    
	    //run the game
	    while (true) {
	    	
	        //first check if mainPile is empty by calling checkCards() in Cards class
	    	//TODO Add your code here
	    	cards.checkCards();
	        
	        //computer's turn
	    	//TODO Add your code here
	    	
	    	target_array=computer.play(target_array);
	        		    
		    //human's turn
	    	//TODO Add your code here
	    	human.play(scanner);
		    //check if game is over, and print out results
	    	//TODO Add your code here
	    	if(checkGameOver(human.getHandCards(), computer.getHandCards(),allWords)) {
	    		break;
	    	}
	    }
	    
	    //close scanner
	    scanner.close();
	}
	
	/**
	 * Asks the user for the number of hand cards.
	 * Prompts again if the user input is not a valid integer, 
	 * or if the number is not between 3 - 10, inclusive.
	 * @param scanner for user input
	 * @return an integer indicating the number of hand cards
	 */
	public int askForLength(Scanner scanner) {
	    
		//TODO Add your code here
		System.out.println("Enter the number of hand cards:");
		int n;
		try{
			n=scanner.nextInt();
			scanner.nextLine();
		}
		catch(InputMismatchException e) {
			System.out.println("Enter an integer");//catches input mismatch and calls again
			n=askForLength(scanner);
		}
		if(n<3||n>10) {
			System.out.println("Enter in the valid range of 3 and 10.");//catches out of bounds according to question and calls again
			n=askForLength(scanner);
		}
		return n;
		
	}
	
	/**
	 * Checks if the game is over.
	 * @param humanHandCards human player's current letters in hand
	 * @param computerHandCards computer player's current letters in hand
	 * @param wordsWithSpecificLength an array containing all the words with a specific length
	 * @return true if computer or human wins the game or if there is a tie, otherwise, false
	 */
	public boolean checkGameOver(String[] humanHandCards, String[] computerHandCards, String[] wordsWithSpecificLength) {
	   
		//TODO Add your code here
		String computerWord=formWord(computerHandCards);
		boolean cwin=false;//to check if computer won
		boolean uwin=false;//to check if user won
		//checks if computer's hand cards are a word
		for(int i=0; i<wordsWithSpecificLength.length;i++) {
			if(computerWord.equals(wordsWithSpecificLength[i])) {
				cwin=true;
				break;
			}
		}
		//checks if user's hand cards are a word
		String userWord=formWord(humanHandCards);
		for(int i=0; i<wordsWithSpecificLength.length;i++) {
			if(userWord.equals(wordsWithSpecificLength[i])) {
				uwin=true;
				break;
			}
		}
		if(uwin==true&&cwin==true) {
			System.out.println("It is a tie.");
			return true;
		}
		else if(cwin==true) {
			System.out.println("Computer wins.");
			return true;
		}
		else if(uwin==true){
			System.out.println("Human wins.");
			return true;
		}
		else {
			return false;
		}
		
	}
	/**
	 * Forms a word from all the elements of a string array
	 * @param handCard
	 * @return the string formed
	 */
	public String formWord(String[] handCard) {
		String string=handCard[0];
		for(int i=1;i<handCard.length;i++) {
			string=string+handCard[i];//joins an array of strings together in a loop
		}
		return string;
	}
}
