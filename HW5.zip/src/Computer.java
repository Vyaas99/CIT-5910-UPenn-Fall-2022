/**
 * Represents a computer player.
 *
 */
public class Computer {
	
	/**
	 * Computer player's hand.
	 */
	String[] handCards;
	
	/**
	 * Access to main pile and discard pile.
	 */
	Cards cards;
	
	/**
	 * Creates a computer player.
	 * Gives access to the main pile and discard pile via given instance of Cards class.
	 * @param cards for access to main pile and discard pile
	 */
	public Computer(Cards cards) {
		this.cards = cards;
	}
	
	/**
	 * Sets computer player's hand.
	 * @param handCards to set
	 */
	public void setHandCards(String[] handCards) {
		
		//TODO Add your code here
		this.handCards=handCards;
		
	}
	
	/**
	 * Gets computer player's hand.
	 * @return computer player's hand
	 */
	public String[] getHandCards() {
		
		//TODO Add your code here
		return this.handCards;
	}
	/**
	 * Forms a target array of words with maximum score possible
	 * @param handCards
	 * @param length
	 * @param wordsWithSpecificLength
	 * @return
	 */
	@SuppressWarnings("unlikely-arg-type")
	public String[] targetArray(String[] handCards, int length, String[] wordsWithSpecificLength) {
		String[] target_array=new String[0];
		int sum=0;
		int max_sum=0;
		int k=0;
		int[] index=new int[0];
		for(int i=0;i<wordsWithSpecificLength.length;i++) {//loop to find maximum similarity words.
			for(int j=0;j<length;j++) {
				if(handCards[j].equals(wordsWithSpecificLength[i].charAt(j))){
					sum=sum+1;
					//System.out.println("sum="+sum);
				}
			}
			if(sum>max_sum) {
				max_sum=sum;//finds out what the maximum similarity is
			}
		}
		for(int i=0;i<wordsWithSpecificLength.length;i++) {
			for(int j=0;j<length;j++) {
				if(handCards[j].equals(wordsWithSpecificLength[i].charAt(j))){
					sum=sum+1;
				}
			}
			if(sum==max_sum) {
				//System.out.println(max_sum);
				index=new int[index.length+1];//loop run to find the index of all the words with the maximum sum.
				index[k]=i;
				k++;
			}
		}
		target_array=new String[index.length];
		for(int i=0;i<index.length;i++) {
			target_array[i]=wordsWithSpecificLength[index[i]];//appends the list with the maximum sum to the target array.
		}
		//System.out.println(target_array.length);//delete
		return target_array;
		}
		
	

	/**
	 * Controls the game play for the computer.
	 * The computer first decides if the letter from the discard pile is useful, if so, 
	 * the computer will take the letter; otherwise, the computer will take the letter from 
	 * main pile and then decide if that's useful.
	 * 
	 * To decide if a given new letter is useful, the computer can put all the potential 
	 * words, which are the most similar words to the current word, in the target array.
	 * If replacing one letter in the current word with the new letter will increase the 
	 * similarity, then the computer decides the given new letter is useful.
	 * 
	 * @param targetArray containing all the most similar words to the current hand cards
	 * @return the newly narrowed down array
	 */
	@SuppressWarnings("unlikely-arg-type")
	public String[] play(String[] targetArray) {
	    
		//TODO Add your code here
		int m=targetArray.length;
		int sum=0;
		String[] handCards1=getHandCards();
		int max_sum=0;
		System.out.println("Computer's turn");
		String topDiscardCard=this.cards.discardPile[0];
		String[] target_array_temp=new String[0];
		for(int i=0;i<m;i++) {//loop checks for maximum score as maximum sum
			for(int j=0;j<handCards1.length;j++) {
				if(handCards1[j].equals(targetArray[i].charAt(j))) {
					sum+=1;
				}
				if(sum>max_sum) {
					max_sum=sum;
				}
			}
		}
		int max_sum2=max_sum;
		String[] handCards2=handCards1;
		int flag=0;
		for(int i=0;i<handCards1.length;i++) {//loop replaces the letter chosen at every place to see if it will result in a higher max sum.
			String temp=handCards2[i];
			handCards2[i]=topDiscardCard;
			for(int p=0;p<m;p++) {//checks for score after replacing
				for(int j=0;j<handCards1.length;j++) {
					if(handCards1[j].equals(targetArray[p].charAt(j))) {
						sum+=1;
					}
					if(sum>max_sum2) {
						max_sum2=sum;
						flag=i;//assigns the index of replacement where the score is highest
					}
				}
			}
			handCards2[i]=temp;//original hand cards obtained
		}
		if(max_sum2>max_sum) {
			System.out.println("Computer took the top card of discard pile,"+topDiscardCard+" and replaced it at "+flag+" position.");
			handCards[flag]=this.cards.getFirstFromDiscardPileAndRemove();//if score is higher, replacement occurs
			System.out.println("Computer Hand:");
		    System.out.print("[");
		    for(int i=0;i<getHandCards().length;i++) {
		    	if(i!=getHandCards().length-1) {
		    		System.out.print(getHandCards()[i]+",");
		    	}
		    	else {
		    		System.out.print(getHandCards()[i]);
		    	}
		    		    
		    }
		    System.out.print("]");
	    	System.out.println("");
		}
		else {
			String topMainCard=this.cards.mainPile[0];//else the same is checked with main pile.
			for(int i=0;i<m;i++) {
				for(int j=0;j<handCards1.length;j++) {
					if(handCards1[j].equals(targetArray[i].charAt(j))) {
						sum+=1;
					}
					if(sum>max_sum) {
						max_sum=sum;
					}
				}
			}
			max_sum2=max_sum;
			handCards2=handCards1;
			flag=0;
			for(int i=0;i<handCards1.length;i++) {
				String temp=handCards2[i];
				handCards2[i]=topMainCard;
				for(int p=0;p<m;p++) {
					for(int j=0;j<handCards1.length;j++) {
						if(handCards1[j].equals(targetArray[p].charAt(j))) {
							sum+=1;
						}
						if(sum>max_sum2) {
							max_sum2=sum;
							flag=i;
						}
					}
				}
				handCards2[i]=temp;
			}
			if(max_sum2>=max_sum) {
				System.out.println("Computer took the top card of main pile,"+topMainCard+" and replaced it at "+flag+" position.");
				handCards[flag]=this.cards.getFirstFromMainPileAndRemove();//if score is higher, replacement occurs.
				System.out.println("Computer Hand:");
			    System.out.print("[");
			    for(int i=0;i<getHandCards().length;i++) {
			    	if(i!=getHandCards().length-1) {
			    		System.out.print(getHandCards()[i]+",");
			    	}
			    	else {
			    		System.out.print(getHandCards()[i]);
			    	}
			    		    
			    }
			    System.out.print("]");
		    	System.out.println("");
			}
			else {
				System.out.println("Computer took the top card of the main pile,"+topMainCard+" and placed it on the discard pile.");
				this.cards.addToDiscardPile(this.cards.getFirstFromMainPileAndRemove());//else it is placed on the discard pile.
				System.out.println("Computer Hand:");
			    System.out.print("[");
			    for(int i=0;i<getHandCards().length;i++) {
			    	if(i!=getHandCards().length-1) {
			    		System.out.print(getHandCards()[i]+",");
			    	}
			    	else {
			    		System.out.print(getHandCards()[i]);
			    	}
			    		    
			    }
			    System.out.print("]");
		    	System.out.println("");
			}
			
		}
		
		for(int i=0;i<targetArray.length;i++) {//runs a loop and adds the words with the maximum score to the renewed target array.
			for(int j=0;j<handCards1.length;j++) {
				if(handCards1[j].equals(targetArray[i].charAt(j))) {
					sum+=1;
				}
				if(sum==max_sum) {
					String[] temp=new String[target_array_temp.length+1];   
					temp[0]=targetArray[i];
					for(int g=1;g<temp.length;g++) {
						temp[g]=targetArray[i];
					}
					target_array_temp=temp;
				}
			}
		}
		return target_array_temp;
		}
}