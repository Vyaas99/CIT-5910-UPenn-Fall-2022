package files;

/**
 * Filters all the words (in an array) based on a given length.
 *
 */
public class WordProcessor {

	/**
	 * Filters the words with a length equal to the given length.
	 * @param allWords array containing all the words
	 * @param length to filter words
	 * @return an array containing all the words with specific length
	 */
	public String[] filterWordList(String[] allWords, int length) {		

		//TODO Add your code here
		String[] allWords2= new String[0];
		String[] temp;
		for(int i=0;i<allWords.length;i++) {
			if(allWords[i].length()==length) {
				temp=allWords2;
				allWords2=new String[temp.length+1];//increases the length of allWords2 array with every word found to match
				allWords2[0]=allWords[i];
				for(int k=0;k<temp.length;k++) {
					allWords2[k+1]=temp[k];//reassigns the rest of the array
				}
			}
		}
		return allWords2;
	}
}
