package battleship;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Homework 7
 * CIT5910_HW7
 * vyaas@seas.upenn.edu
 * 20723731
 * @author vyaas
 *
 */
public class BattleshipGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BattleshipGame game = new BattleshipGame();
	       while(game.runGame()) {
	           continue;//continues to run game till runGame method returns false
	       }
	       System.out.println("Thank you! Play me whenever you want!");//once the runGame method returns false, this is printed

	}
	
	public boolean runGame() {
        Ocean ocean = new Ocean();
        ocean.placeAllShipsRandomly();
        Scanner scan = new Scanner(System.in);
        ocean.print();
        while (!ocean.isGameOver()) {
        	int x = askForInteger(scan);//asks for location
        	int y = askForInteger(scan);
            if(ocean.shootAt(x,y)) {
                System.out.println("hit");//prints hit if shoot is successful
                Ship[][] ships=ocean.getShipArray();//gets the current ship array(ocean)
                if(ships[x][y].isSunk()) {
                    System.out.println("You sank one " + ships[x][y].getShipType() + ".");//prints only if ship has sunk
                }
            } else {
                System.out.println("miss");//prints if the hit misses
            }
            ocean.print();//prints the ocean after the shot
        }
        //displays final score
        System.out.println("Your final score is " + ocean.getShotsFired() + ".");
        //asks if the user wants to play again
        String prompt="Do you want to play again?";
        boolean playAgain = askYesOrNo(prompt,scan);
        return playAgain;
    }
	public int askForInteger(Scanner scan) {
		System.out.println("Please enter two integers between 0 and 9 (0 and 9 included) and use \"Enter\" to break lines.");
		int x;
		try {
			x=scan.nextInt();
			scan.nextLine();//consumes line
		}
		catch(InputMismatchException e) {
			System.out.println("Enter an integer");
			x=askForInteger(scan);//asks again if input is not an integer
		}
		if(x<0||x>9) {
			System.out.println("Enter within the range.");
			x=askForInteger(scan);//asks again if out of bounds
		}
		return x;
	}
	public boolean askYesOrNo(String prompt, Scanner scanner) {
		
		System.out.println(prompt);
		try {
			String yesOrNoString=scanner.nextLine();//Scans for user input.
			yesOrNoString=yesOrNoString.toLowerCase();//Converts the user input to lowercase.
			String strippedString=yesOrNoString.strip();//Strips the updated user input's leading and trailing spaces.
			boolean yesOrNo=strippedString.startsWith("y");//Checks if the updated user input starts with "y."
			return yesOrNo;
		}
		catch(InputMismatchException e) {//Catches input mismatch error.
			boolean yesOrno=askYesOrNo(prompt,scanner);//Prompts the same question again till we get a valid input.
			return yesOrno;
		}
		
		
	}

}
