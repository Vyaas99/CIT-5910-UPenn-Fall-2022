package battleship;

public abstract class Ship {
	/**
	 * bow row
	 */
	private int bowRow;
	/**
	 * bow column
	 */
	private int bowColumn;
	/**
	 * length of ship
	 */
	private int length;
	/**
	 * determines whether the boat is horizontal(true) or vertical(false)
	 */
	private boolean horizontal;
	/**
	 * determines the parts of the ship hit. It is considered accordingly based on the length of the ship
	 */
	private boolean[] hit= {false,false,false,false};
	
	/**
	 * constructor for the length of the ship
	 * @param length
	 */
	public Ship(int length) {
		this.length=length;
		this.hit=new boolean[length];
	}
	
	//All getters
	int getLength() {
		return this.length;
	}
	int getBowRow() {
		return this.bowRow;
	}
	int getBowColumn() {
		return this.bowColumn;
	}
	boolean[] getHit() {
		return this.hit;
	}
	boolean isHorizontal() {
		return this.horizontal;
	}
	//All setters
	void setBowRow(int row) {
		this.bowRow=row;
	}
	void setBowColumn(int column) {
		this.bowColumn=column;
	}
	
	void setHorizontal(boolean horizontal) {
		this.horizontal=horizontal;
	}
	//abstract class. subclasses of ship overrides it.
	abstract String getShipType();
	
	/**
	 * checks whether it is okay to place a ship at the given location
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 * @return
	 */
	boolean okToPlaceShipAt(int row, int column, boolean horizontal,
			Ocean ocean) {
		if (row < 0 || row > 9 || column < 0 || column > 9) {
	        return false;//returns false if the row or the column is out of bounds
	    }
		if(horizontal) {
			if(column-this.length<0) {//returns false if out of bounds
				return false;
			}
		    for(int i=column;i>column-this.length;i--) {
		    	if(ocean.isOccupied(row,i)||ocean.isOccupied(row-1,i)||ocean.isOccupied(row+1,i)||ocean.isOccupied(row-1,i-1)||ocean.isOccupied(row-1,i+1)||ocean.isOccupied(row+1,i-1)||ocean.isOccupied(row+1,i+1)||ocean.isOccupied(row,i-1)||ocean.isOccupied(row,i+1)) {
		    		return false;//returns false if it is adjacent in any way to a part of any ship.
		    	}
		    }
		return true;
		}
		else {
			if(row-this.length<0) {//returns false if out of bounds
				return false;
			}
			for(int i=row;i>row-this.length;i--) {
				if(ocean.isOccupied(i,column)||ocean.isOccupied(i-1,column)||ocean.isOccupied(i+1,column)||ocean.isOccupied(i-1,column-1)||ocean.isOccupied(i-1,column+1)||ocean.isOccupied(i+1,column-1)||ocean.isOccupied(i+1,column+1)||ocean.isOccupied(i,column-1)||ocean.isOccupied(i,column+1)) {
		    		return false;//returns false if it is adjacent in any way to a part of any ship.
		    	}
			}
			return true;//if the above steps do not return false, it is okay to place and returns true here.
		}
	}
	
	/**
	 * places ship at the given location
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 */
	void placeShipAt(int row, int column, boolean horizontal, Ocean
			ocean) {
		
		//sets the bow row,column and the horizontal.
		this.setBowRow(row);
		this.setBowColumn(column);
		this.setHorizontal(horizontal);
		Ship[][] ships=ocean.getShipArray();//gets ship array
		if(horizontal) {
			for(int i=column;i>column-this.length;i--) {//places ship towards the left if horizontal
				ships[row][i]=this;
				}
			}
		else {
			for(int i=row;i>row-this.length;i--) {//places ship towards the top if vertical
				ships[i][column]=this;
				}
			}
		
		
				
	}
	
	/**
	 * shoots at the given location
	 * @param row
	 * @param column
	 * @return
	 */
	boolean shootAt(int row, int column) {
		if(!this.isSunk()) {//attempts shooting only if the ship has not sunk
			if(this.horizontal) {
				if(row==this.bowRow) {//if horizontal and bow row is not equal to given row, returns false
					for(int i=this.bowColumn;i>this.bowColumn-this.length;i--) {
						if(i==column) {//only if the ship is present in the column does the hit gets updated and returns true
							this.hit[this.bowColumn-i]=true;
							return true;
						}
					}
				}
				else {
					return false;
				}
			}
			else {
				if(column==this.bowColumn) {//if vertical and bow column is not equal to given column, returns false
					for(int i=this.bowRow;i>this.bowRow-this.length;i--) {
						if(i==row) {
							this.hit[this.bowRow-i]=true;
							return true;
						}
					}
				}
				else {
					return false;
				}
			}
		}
		else {
			return false;
		}
		return false;
	}
	
	/**
	 * checks if a ship has sunk
	 * @return
	 */
	boolean isSunk() {
		for(int i=this.hit.length-1;i>=0;i--) {
			if(this.hit[i]==false) {//checks all the hit elements
				return false;//if any of them shows false, returns false
			}
		}
		return true;
    }
	//@Override
	public String toString() {
		if(this.isSunk()) {//if the ship has sunk, returns "s"
			return "s";
		}
		else {
			return "x";//if not, returns "x"
		}
	}
	
}


