package battleship;

public class Cruiser extends Ship{

	public Cruiser() {
		super(3);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getShipType() {
		// TODO Auto-generated method stub
		return "cruiser";
	}

}
