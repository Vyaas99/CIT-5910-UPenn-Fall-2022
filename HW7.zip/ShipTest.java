package battleship;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ShipTest {

	Ocean ocean;
	Ship ship;
	
	@BeforeEach
	void setUp() throws Exception {
		ocean = new Ocean();
	}

	@Test
	void testGetLength() {
		ship = new Battleship();
		assertEquals(4, ship.getLength());
		
		//TODO
		//More tests
		ship= new Cruiser();
		assertEquals(3, ship.getLength());
		ship= new Submarine();
		assertEquals(1, ship.getLength());
		
	}

	@Test
	void testGetBowRow() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		
		//TODO
		//More tests
		battleship = new Battleship();
		row = 1;
		column = 4;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		
		battleship = new Battleship();
		row = 9;
		column = 9;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
	}

	@Test
	void testGetBowColumn() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		battleship.setBowColumn(column);
		assertEquals(column, battleship.getBowColumn());	
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 9;
		column = 9;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		
		battleship = new Battleship();//new ship
		row = 0;
		column = 9;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
	}

	@Test
	void testGetHit() {
		ship = new Battleship();
		boolean[] hits = new boolean[4];
		assertArrayEquals(hits, ship.getHit());
		assertFalse(ship.getHit()[0]);
		assertFalse(ship.getHit()[1]);
		
		//TODO
		//More tests
		ship = new Cruiser();//new ship
		hits = new boolean[3];
		assertArrayEquals(hits, ship.getHit());
		assertFalse(ship.getHit()[0]);
		assertFalse(ship.getHit()[1]);
		
		ship = new Destroyer();//new ship
		hits = new boolean[2];
		assertArrayEquals(hits, ship.getHit());
		assertFalse(ship.getHit()[0]);
		assertFalse(ship.getHit()[1]);
	}
	@Test
	void testGetShipType() {
		ship = new Battleship();
		assertEquals("battleship", ship.getShipType());
		
		//TODO
		//More tests
		ship = new Destroyer();
		assertEquals("destroyer", ship.getShipType());
		
		ship = new Submarine();
		assertEquals("submarine", ship.getShipType());
	}
	
	@Test
	void testIsHorizontal() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertTrue(battleship.isHorizontal());
		
		//TODO
		//More tests	
		battleship = new Battleship();//new ship
		row = 9;
		column = 9;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertTrue(battleship.isHorizontal());
		
		battleship = new Battleship();//new ship
		row = 9;
		column = 9;
		horizontal = false;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertFalse(battleship.isHorizontal());
	}
	
	@Test
	void testSetBowRow() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.setBowRow(row);
		assertEquals(row, battleship.getBowRow());
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 1;
		column = 9;
		horizontal = true;
		battleship.setBowRow(row);
		assertEquals(row, battleship.getBowRow());
		
		battleship = new Battleship();//new ship
		row = 5;
		column = 6;
		horizontal = true;
		battleship.setBowRow(row);
		assertEquals(row, battleship.getBowRow());
	}

	@Test
	void testSetBowColumn() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.setBowColumn(column);
		assertEquals(column, battleship.getBowColumn());
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 1;
		column = 9;
		horizontal = true;
		battleship.setBowColumn(column);
		assertEquals(column, battleship.getBowColumn());
		
		battleship = new Battleship();//new ship
		row = 5;
		column = 6;
		horizontal = true;
		battleship.setBowColumn(column);
		assertEquals(column, battleship.getBowColumn());
	}

	@Test
	void testSetHorizontal() {
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.setHorizontal(horizontal);
		assertTrue(battleship.isHorizontal());
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 9;
		column = 4;
		horizontal = false;
		battleship.setHorizontal(horizontal);
		assertFalse(battleship.isHorizontal());
		
		battleship = new Battleship();//new ship
		row = 6;
		column = 0;
		horizontal = true;
		battleship.setHorizontal(horizontal);
		assertTrue(battleship.isHorizontal());
	}

	@Test
	void testOkToPlaceShipAt() {
		
		//test when other ships are not in the ocean
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		boolean ok = battleship.okToPlaceShipAt(row, column, horizontal, ocean);
		assertTrue(ok, "OK to place ship here.");
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 0;
		column = 10;
		horizontal = true;
		ok = battleship.okToPlaceShipAt(row, column, horizontal, ocean);
		assertFalse(ok, "Not OK to place ship here.");//checks false for out of bounds
		
		Ship battleship2 = new Battleship();//new ship
		row = 0;
		column = 3;
		horizontal = true;
		ok = battleship2.okToPlaceShipAt(row, column, horizontal, ocean);
		assertFalse(ok, "Not OK to place ship here.");//checks if we can place ship on another ship
	}
	
	@Test
	void testOkToPlaceShipAtAgainstOtherShipsOneBattleship() {
		
		//test when other ships are in the ocean
		
		//place first ship
		Battleship battleship1 = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		boolean ok1 = battleship1.okToPlaceShipAt(row, column, horizontal, ocean);
		assertTrue(ok1, "OK to place ship here.");
		battleship1.placeShipAt(row, column, horizontal, ocean);

		//test second ship
		Battleship battleship2 = new Battleship();
		row = 1;
		column = 4;
		horizontal = true;
		boolean ok2 = battleship2.okToPlaceShipAt(row, column, horizontal, ocean);
		assertFalse(ok2, "Not OK to place ship vertically adjacent below.");
		
		//TODO
		//More tests
		//test third ship
		Battleship battleship3 = new Battleship();
		row = 0;
		column = 5;//checks if it is indeed not okay to place horizontally adjacent to ship 1.
		horizontal = false;
		boolean ok3 = battleship3.okToPlaceShipAt(row, column, horizontal, ocean);
		assertFalse(ok3, "OK to place ship vertically adjacent below.");
		
		//test ship 4
		Battleship battleship4 = new Battleship();
		row = 2;
		column = 5;//checks if it is indeed not okay to place diagonally adjacent to ship 2.
		horizontal = false;
		boolean ok4 = battleship4.okToPlaceShipAt(row, column, horizontal, ocean);
		assertFalse(ok4, "OK to place ship vertically adjacent below.");
	}

	@Test
	void testPlaceShipAt() {
		
		Ship battleship = new Battleship();
		int row = 0;
		int column = 4;
		boolean horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		assertEquals(column, battleship.getBowColumn());
		assertTrue(battleship.isHorizontal());
		
		assertEquals("empty", ocean.getShipArray()[0][0].getShipType());
		assertEquals(battleship, ocean.getShipArray()[0][1]);
		

		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 3;
		column = 6;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		assertEquals(column, battleship.getBowColumn());
		assertTrue(battleship.isHorizontal());
		
		assertEquals("empty", ocean.getShipArray()[0][9].getShipType());
		assertEquals(battleship, ocean.getShipArray()[3][6]);
		assertEquals("battleship", ocean.getShipArray()[3][6].getShipType());
		
		battleship = new Battleship();//new ship
		row = 6;
		column = 9;
		horizontal = false;
		battleship.placeShipAt(row, column, horizontal, ocean);
		assertEquals(row, battleship.getBowRow());
		assertEquals(column, battleship.getBowColumn());
		assertFalse(battleship.isHorizontal());
		
		assertEquals("empty", ocean.getShipArray()[7][9].getShipType());
		assertEquals(battleship, ocean.getShipArray()[6][9]);
		assertEquals("battleship", ocean.getShipArray()[6][9].getShipType());
	}

	@Test
	void testShootAt() {
		
		Ship battleship = new Battleship();
		int row = 0;
		int column = 9;
		boolean horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		
		assertFalse(battleship.shootAt(1, 9));
		boolean[] hitArray0 = {false, false, false, false};
		assertArrayEquals(hitArray0, battleship.getHit());
		
		//TODO
		//More tests
		battleship = new Battleship();//new ship
		row = 9;
		column = 9;
		horizontal = true;
		battleship.placeShipAt(row, column, horizontal, ocean);
		
		assertTrue(battleship.shootAt(9, 9));
		boolean[] hitArray1 = {true, false, false, false};
		assertArrayEquals(hitArray1, battleship.getHit());
		
		battleship = new Battleship();//new ship
		row = 9;
		column = 9;
		horizontal = false;
		battleship.placeShipAt(row, column, horizontal, ocean);
		
		assertTrue(battleship.shootAt(6, 9));
		boolean[] hitArray2 = {false, false, false, true};
		assertArrayEquals(hitArray2, battleship.getHit());
		assertFalse(battleship.shootAt(10, 0));//checks out of bounds
		
	}
	
	@Test
	void testIsSunk() {
		
		Ship submarine = new Submarine();
		int row = 3;
		int column = 3;
		boolean horizontal = true;
		submarine.placeShipAt(row, column, horizontal, ocean);
		
		assertFalse(submarine.isSunk());
		assertFalse(submarine.shootAt(5, 2));
		assertFalse(submarine.isSunk());
		
		//TODO
		//More tests
		submarine = new Submarine();//new ship
		row = 9;
		column = 9;
		horizontal = true;
		submarine.placeShipAt(row, column, horizontal, ocean);
		
		assertFalse(submarine.isSunk());
		assertTrue(submarine.shootAt(9,9));
		assertTrue(submarine.isSunk());
		
		Ship destroyer = new Destroyer();//new ship
		row = 9;
		column = 9;
		horizontal = true;
		destroyer.placeShipAt(row, column, horizontal, ocean);
		
		assertFalse(destroyer.isSunk());
		assertTrue(destroyer.shootAt(9,9));
		assertFalse(destroyer.isSunk());
		assertTrue(destroyer.shootAt(9,8));
		assertTrue(destroyer.isSunk());
		
	}

	@Test
	void testToString() {
		
		Ship battleship = new Battleship();
		assertEquals("x", battleship.toString());
		
		int row = 9;
		int column = 1;
		boolean horizontal = false;
		battleship.placeShipAt(row, column, horizontal, ocean);
		battleship.shootAt(9, 1);
		assertEquals("x", battleship.toString());
		
		//TODO
		//More tests
		Ship submarine = new Submarine();//new ship
		assertEquals("x", submarine.toString());
		
		row = 9;
		column = 9;
		horizontal = false;
		submarine.placeShipAt(row, column, horizontal, ocean);
		submarine.shootAt(9, 9);
		assertTrue(submarine.isSunk());
		assertEquals("s",submarine.toString());
		
		Ship destroyer = new Destroyer();//new ship
		assertEquals("x", destroyer.toString());
		row = 5;
		column = 5;
		horizontal = true;
		destroyer.placeShipAt(row, column, horizontal, ocean);
		destroyer.shootAt(5, 5);
		assertFalse(destroyer.isSunk());//ship not sunk
		assertEquals("x",destroyer.toString());
		destroyer.shootAt(5, 4);
		assertTrue(destroyer.isSunk());
		assertEquals("s",destroyer.toString());//ship sunk
		
	}

}
