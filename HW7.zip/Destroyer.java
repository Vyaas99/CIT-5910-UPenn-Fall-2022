package battleship;

public class Destroyer extends Ship{

	public Destroyer() {
		// TODO Auto-generated constructor stub
		super(2);
	}

	@Override
	public String getShipType() {
		// TODO Auto-generated method stub
		return "destroyer";
	}

}
