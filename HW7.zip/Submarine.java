package battleship;

public class Submarine extends Ship{

	public Submarine() {
		super(1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getShipType() {
		// TODO Auto-generated method stub
		return "submarine";
	}

}
