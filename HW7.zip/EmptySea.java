package battleship;

class EmptySea extends Ship{

	public EmptySea() {
		super(0);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getShipType() {
		// TODO Auto-generated method stub
		return "empty";
	}
	@Override
	public boolean shootAt(int row, int column) {
		return false;
	}
	@Override
	public boolean isSunk() {
		return false;
	}
	@Override
	public String toString() {
		return "-";
	}
	
}
