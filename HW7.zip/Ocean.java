package battleship;

import java.util.Random;

public class Ocean {
	/**
	 * Ocean 
	 */
	private Ship[][]ships = new Ship[10][10];
	/**
	 * Total shots fired in the game
	 */
	private int shotsFired;
	/**
	 * hit count
	 */
	private int hitCount;
	/**
	 * number of ships sunk
	 */
	private int shipsSunk;
	/**
	 * checks whether a location has been fired upon or not
	 */
	boolean[][] firedOrNot = new boolean[10][10];
	
	/**
	 * Constructor for ocean
	 */
	public Ocean() {
		
		for(int i=0;i<10;i++) {
			for(int j=0;j<10;j++) {
				this.ships[i][j]=new EmptySea();//adds empty sea in every element of the ocean array(Ship)
				Ship a=this.ships[i][j];
				//sets all the bow rows and bow columns and the horizontal
				a.setBowColumn(j);
				a.setBowRow(i);
				a.setHorizontal(true);
			}
		}
	}
	
	/**
	 * returns whether a location is occupied or not
	 * @param row
	 * @param column
	 * @return
	 */
	boolean isOccupied(int row,int column) {
		if (row < 0 || row > 9 || column < 0 || column > 9) {
	        return false;//returns false if the row or the column is out of bounds
	    }
		if (ships[row][column] instanceof EmptySea) {//returns false if the element at the location is an instance of empty sea
		    return false;
		}
		return true;
	}
	
	/**
	 * places ships randomly in the ocean
	 */
	void placeAllShipsRandomly() {
		//create the fleet of ships
		Ship[] fleet= {new Battleship(),new Cruiser(),new Cruiser(),new Destroyer(),new Destroyer(),new Destroyer(), new Submarine(),new Submarine(),new Submarine(),new Submarine() };
		//creates random
		Random random=new Random();
		for(int i=0;i<10;i++) {
			Ship currentShip=fleet[i];//sets current ship as one among the fleet
			while (true) {//loop keeps running until the method inside breaks it
	            int x = random.nextInt(10);
	            int y = random.nextInt(10);
	            int flag=random.nextInt(2);//to choose whether ship should be horizontal or vertical randomly
	            boolean horizontal;
	            if(flag==0) {
	            	horizontal=true;
	            }
	            else {
	            	horizontal=false;
	            }
	            if (currentShip.okToPlaceShipAt(x, y, horizontal, this)) {
	                currentShip.placeShipAt(x, y, horizontal, this);//places ship if it is okay to place the ship at the location
	                break;//breaks the loop only if we are able to place the current ship chosen initially
	            }
	        }
		}
			
	}
	
	/**
	 * shoots at the given location
	 * @param row
	 * @param column
	 * @return
	 */
	boolean shootAt(int row, int column) {
		if (row < 0 || row > 9 || column < 0 || column > 9) {
	        return false;//returns false if the row or the column is out of bounds
	    }
		this.firedOrNot[row][column] = true;//sets the hit ocean array true at the given location
		this.shotsFired++;//increments shots fired
		if (this.ships[row][column].shootAt(row, column)) {//if an unsunken ship is shot,
		    this.hitCount++;//increments the hit count
		    Ship a=this.ships[row][column];
		    if(a.isSunk()) {//if the ship has sunk,
		    	this.shipsSunk++;//increments ship sunk count
		    }
		    return true;
		} else {
		    return false;   
		}
	}
	
	/**
	 * gets total shots fired
	 * @return
	 */
	int getShotsFired() {
		return this.shotsFired;
	}
	/**
	 * gets hit counts
	 * @return
	 */
	int getHitCount() {
		return this.hitCount;
	}
	/**
	 * gets number of ships sunk
	 * @return
	 */
	int getShipsSunk() {
		return this.shipsSunk;
	}
	/**
	 * gets boolean to see whether the game is over or not
	 * @return
	 */
	boolean isGameOver() {
		int count=0;
		for(int i=0;i<10;i++) {
			for(int j=0;j<10;j++) {
				if(this.ships[i][j].isSunk()) {
					count++;
				}
			}
		}
		if(count==20) {//20 is the number of locations occupied by the ships. number of s on the ocean after all the ships have sunk
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * gets the ocean
	 * @return
	 */
	Ship[][] getShipArray(){
		return this.ships;
	}
	/**
	 * prints the game
	 */
	void print() {
		for(int i=-1;i<10;i++) {
			for(int j=-1;j<10;j++) {
				if(i==-1&&j==-1) {
					System.out.print("  ");
				}
				if(i==-1&&j>-1) {
					if(i==-1&&j==9) {
						System.out.print(j+" \n");
					}
					else {
						System.out.print(j+" ");
					}
				}
				if(i>-1&&j==-1) {
					System.out.print(i+" ");
				}
				if(i>-1&&j>-1) {
					if(j==9) {
						if(!firedOrNot[i][j]) {
							System.out.print(". \n");//starts new line if the end of the column is reached
						}
						else {
							System.out.print(this.ships[i][j].toString()+" \n");//starts new line if the end of the column is reached
						}
						
					}
					else {
						if(!firedOrNot[i][j]) {
							System.out.print(". ");//prints "." if it has not been fired upon yet
						}
						else {
							System.out.print(this.ships[i][j].toString()+" ");//prints "x" or "s" based on whether the ship has been hit and not sunk or hit and sunk. 
							//prints "-" otherwise
						}
						
					}
				}
				
				
			}
		}
	}
}
