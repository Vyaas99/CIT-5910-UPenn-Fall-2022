package battleship;

class Battleship extends Ship{
    
	/**
	 * constructor of subclass
	 */
	public Battleship() {//zero argument constructor
		super(4);//calls the constructor of the superclass with integer 4.
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getShipType() {
		// TODO Auto-generated method stub
		return "battleship";//overrides the getShipType() method in the superclass and returns the name of the ship
	}
//same comments for the other subclasses of ship
}
