import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
/**
 * Name: Vyaas Valsaraj
 * Penn ID:20723731
 * Statement of Work: I would like to state that I worked alone on this supermarket game without any help.
 * @author vyaas
 *
 */
public class Supermarket {

	public static void main(String[] args) {
		//unit price of a lottery ticket
		double LOTTERY_UNIT_PRICE = 2.0;
		//unit price of an apple
		double APPLE_UNIT_Price = .99;
		//unit price of a can of beans
		double CANNED_BEANS_UNIT_PRICE = 1.58;
		//unit price of a soda
		double SODA_UNIT_PRICE = 1.23;
		//the user has initial $5 for shopping
		double money = 5.0;
		//the user has spent $0 initially
		double moneySpent = 0;
		//the amounts of lottery tickets, apples, cans of beans, and sodas the user has purchased
		int lotteryAmount = 0;
		int appleAmount = 0;
		int cannedBeansAmount = 0;
		int sodaAmount = 0;
		int winnings=0;
		//create a scanner for getting user input
		Scanner scan = new Scanner(System.in);
		//TODO Insert your code here
		
		//Printing the welcome message
		System.out.println("Welcome to the Supermarket!\nHere is what we have in stock:-\n");
		System.out.println("Lottery Tickets at the cost of 2 dollars each.");
		System.out.println("Apples at the cost of 0.99 dollars each.");
		System.out.println("Cans of beans at the cost of 1.58 dollars each.");
		System.out.println("Sodas at the cost of 1.23 dollars each.\n");
		System.out.println("You have $5 available.");
		System.out.println("Do you want to buy a lottery ticket for $2 for a chance of winning $2-$10?");
		System.out.println("Enter y/n:");
		String lt;
		Random random=new Random();
		int winOrlose;
		lt=scan.nextLine();//scanning for user input.
		lt=lt.toLowerCase();//converting user input to lowercase incase they enter an uppercase character.
		if (lt.equals("y")) {
			moneySpent=2;
			money-=2;
			lotteryAmount+=1;
			winOrlose=random.nextInt(3);
			//choosing 2 as the condition equivalent to winning with 0 and 1 equivalent to losing to create a 33% chance of winning.
			if (winOrlose==2) {
				System.out.println("You have won the lottery!");
				winnings=random.nextInt(9)+2;
				System.out.println("Congratulations! You have won "+winnings+" dollars.");
				money+=winnings;
			}
			else {
				System.out.println("You have lost the lottery.");
			}
		}
		else {
			System.out.println("No lottery tickets are purchased.");
		}
		System.out.println("");//gap lines for aesthetic purposes and for more clarity.
		System.out.println("");
		System.out.println("");
		System.out.println("Money available:"+money);
		String apples;
		System.out.println("Do you want to purchase apples?");
		apples=scan.nextLine();
		apples.toLowerCase();
		if (apples.equals("y")) {
			//using try to catch input mismatch error.
			try{
				System.out.println("Enter the number of apples you would like to purchase:");
				int number=scan.nextInt();
				scan.nextLine();//consuming next line.
				System.out.println("You want to buy "+number+" apple(s).");
				double appleCost=APPLE_UNIT_Price*number;
				BigDecimal bd3 =new BigDecimal(appleCost);
				bd3=bd3.setScale(2,RoundingMode.HALF_UP);
				appleCost=bd3.doubleValue();
				System.out.println("It will cost "+appleCost+" dollars.");
				if (money<appleCost){
					System.out.println("Not enough money.");
				}
				else {
					System.out.println("Enough money available for the desired purchase.");
					money-=appleCost;
					moneySpent+=appleCost;
					appleAmount+=number;
				}
			}
			catch(InputMismatchException e) {
				System.out.println("Numerical Values only. No apples selected.");
			}
		}
		else {
			System.out.println("No apples were purchased.");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		BigDecimal bd =new BigDecimal(money);//rounding of the long double to two decimal places with the following lines.
		bd=bd.setScale(2,RoundingMode.HALF_UP);
		money=bd.doubleValue();
		System.out.println("Money available:"+money);
		String beans;
		System.out.println("Do you want to purchase beans?");
		beans=scan.nextLine();
		beans.toLowerCase();
		if (beans.equals("y")) {
			try{
				System.out.println("Enter the amount of can(s) of beans you would like to purchase:");
				int number = scan.nextInt();
				scan.nextLine();//consuming next empty line.
				System.out.println("You want to buy "+number+" can(s) of beans.");
				double beansCost=CANNED_BEANS_UNIT_PRICE*number;
				BigDecimal bd4 =new BigDecimal(beansCost);
				bd4=bd4.setScale(2,RoundingMode.HALF_UP);
				beansCost=bd4.doubleValue();
				System.out.println("It will cost "+beansCost+" dollars.");
				if (money<beansCost){
					System.out.println("Not enough money.");
				}
				else {
					System.out.println("Enough money available for the desired purchase.");
					money-=beansCost;
					moneySpent+=beansCost;
					cannedBeansAmount+=number;
				}
			}
			catch(InputMismatchException e) {
				System.out.println("Numerical Values only. No can(s) of beans selected.");
			}
		}
		else {
			System.out.println("No can(s) of beans were purchased.");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		BigDecimal bd1 =new BigDecimal(money);
		bd1=bd1.setScale(2,RoundingMode.HALF_UP);
		money=bd1.doubleValue();
		System.out.println("Money available:"+money);
		String sodas;
		System.out.println("Do you want to purchase soda?");
		sodas=scan.nextLine();
		sodas.toLowerCase();
		if (sodas.equals("y")) {
			try{
				System.out.println("Enter the number of sodas you would like to purchase:");
				int number = scan.nextInt();
				scan.nextLine();//consuming next line.
				System.out.println("You want to buy "+number+" sodas.");
				double sodasCost=SODA_UNIT_PRICE*number;
				BigDecimal bd5 =new BigDecimal(sodasCost);
				bd5=bd5.setScale(2,RoundingMode.HALF_UP);
				sodasCost=bd5.doubleValue();
				System.out.println("It will cost "+sodasCost+" dollars.");
				if (money<sodasCost){
					System.out.println("Not enough money.");
				}
				else {
					System.out.println("Enough money available for the desired purchase.");
					money-=sodasCost;
					moneySpent+=sodasCost;
					sodaAmount+=number;
				}
			}
			catch(InputMismatchException e) {
				System.out.println("Numerical Values only. No sodas selected.");
			}
		}
		else {
			System.out.println("No sodas were purchased.");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		BigDecimal bd2 =new BigDecimal(money);
		bd2=bd2.setScale(2,RoundingMode.HALF_UP);
		money=bd2.doubleValue();
		//Printing the ending message bidding farewell.
		System.out.println("Money left:"+money);
		System.out.println("Money won in lottery:"+winnings);
		System.out.println("Number of lottery tickets bought:"+lotteryAmount);
		System.out.println("Number of apples bought:"+appleAmount);
		System.out.println("Number of can(s) of beans bought:"+cannedBeansAmount);
		System.out.println("Number of soda(s) bought:"+sodaAmount);
		System.out.println("Good bye!");
		
				
		//close the scanner
		scan.close();

	}

}
