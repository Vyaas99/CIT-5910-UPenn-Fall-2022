import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
/**
 * Name:Vyaas Valsaraj
 * Penn ID:vyaas@seas.upenn.edu
 * Statement of Work: I have done this work on my own by taking instructions from canvas.
 * A game of blackjack-Simple21
 * HW4_CIT5910
 * 20723731
 * @author vyaas
 *
 */
public class Simple21 {

	/**
	 * Entry point to the program. This should not be modified.
	 * Creates instance of Simple21 class and calls run().
	 * @param args
	 */
	public static void main(String[] args) {

		Simple21 simple21 = new Simple21();
		simple21.run();
	}

	/**
	 * This method runs and controls the overall flow of the program.
	 */
	void run() {

		//print the game instructions
		printInstructions();

		//create scanner for user input
		Scanner scanner = new Scanner(System.in);

		//get and set user's name
		System.out.println("What's your name?");
		String username = scanner.nextLine();

		//set computer's name
		String computerName = "Computer";

		
		//TODO insert the rest of the code in the run method here
		play(username,computerName,scanner);//Starts the game.
		String p="Would you like to play again?";//Asks user if they want to play again after the previous game ends.
		if(askYesOrNo(p,scanner)) {
			String prompt="Would you like to modify your username?";//Stores prompt.
			boolean uName=askYesOrNo(prompt,scanner);//Asks user if they want to modify username.
			if(uName) {//If user wants to modify, it asks user to enter the new name.
				System.out.println("Enter the username you want:");
				username=scanner.nextLine();//Scans for user input and stores it.
			}
			play(username,computerName,scanner);//Starts a new game.
		}
		else {
			System.out.println("If you want to play again, run me anytime!");//If the user does not want to play another game, it prints out this message.
		}

		//close the scanner
		scanner.close();
	}

	/**
	 * This method controls the game and logic for the given user and computer.
	 * @param username for the user
	 * @param computerName for the computer
	 * @param scanner for getting user input
	 */
	void play(String username, String computerName, Scanner scanner) {

		//TODO Insert your code here
		int hiddenPoints=nextCard();//Initializing points for user.
		int visiblePoints=nextCard();
		
		int totalPoints=visiblePoints+hiddenPoints;
		printStatus(true,username,hiddenPoints,visiblePoints,totalPoints);//Printing status of user.
		
		int hiddenPointsComp=nextCard();//Initializing
		int visiblePointsComp=nextCard();
		
		int totalPointsComp=visiblePointsComp+hiddenPointsComp;
		printStatus(false,computerName,hiddenPointsComp,visiblePointsComp,totalPointsComp);//Printing status of computer.
		
		String prompt="Do you want to take another card,"+username+"?(y/n)";//Prompt to take another card stored in prompt variable.
		boolean aUserPass=true;//Declaring variables used to check whether user passed and wants to play
		boolean aUser;
		boolean aCompPass=true;//Declaring variables used to check whether computer passed and wants to play
		boolean aComp;
		boolean gameOverNot=isGameOver(aUserPass,aCompPass);//Initializing whether game is over or not to a variable.
		//Runs a loop till game is over,i.e., when both user and computer passes.
		while(gameOverNot) {
			if(aUserPass) {//Set of instructions coming up should not be executed if the user has passed, hence the if condition.
				aUser=askYesOrNo(prompt,scanner);//Scanning for user input to see if they want to take another card.
				if(aUser==true) {
					int vP=nextCard();//Getting a card and storing its value in a temporary variable.
					System.out.println(username+" gets "+vP+" point(s).");//Prints the points the user got.
					visiblePoints+=vP;//Adds the points the user got to the existing visible points.
					totalPoints=visiblePoints+hiddenPoints;//Stores the new total points.
					
					printStatus(true,username,hiddenPoints,visiblePoints,totalPoints);//Prints the new Status for the user.
					
					
				}
				else {
				    aUserPass=false;//Declaring that the user passed and will not get another chance to get a new card.
					System.out.println(username+" passes.");//Prints out to the players that the user has passed.
				}
			}
			aComp=takeAnotherCard(totalPointsComp,visiblePoints);//Computer decides whether to take a new card or not based on its own strategy.
			if(aCompPass) {//Same code as the user with different variables.
				if(aComp==true){
					int vPC=nextCard();
					System.out.println(computerName+" gets "+vPC+" point(s).");
					visiblePointsComp+=vPC;
					totalPointsComp=visiblePointsComp+hiddenPointsComp;
					printStatus(false,computerName,hiddenPointsComp,visiblePointsComp,totalPointsComp);
					
				}
				else{
					aCompPass=false;
					System.out.println(computerName+" passes.");
				}
			}
			
			gameOverNot=isGameOver(aUserPass,aCompPass);//Checks if both the players passed. If not, the loop continues to run.
			//System.out.println("Game Over:"+gameOverNot);
		}
		printWinner(username,totalPoints,computerName,totalPointsComp);//Prints the winner of the game once the loop has been exited, i.e., when both the players have passed.
		
	}

	/**
	 * Prints out instructions for the game.
	 */
	void printInstructions() {
		
		//TODO Insert your code here
		//Prints instructions of the game.
		System.out.println("Let's play Simple21!");
		System.out.println("You'll play against the computer.");
		System.out.println("Try to get as close to 21 as possible, without going over.");
		
	}

	/**
	 * Displays the given prompt and asks the user for input using the given scanner.  
	 * If the user's input starts with "y", returns true.
	 * If the user's input starts with "n", returns false.
	 * 
	 * For example, calling askYesOrNo("Do you want to play again? (y/n) ") 
	 * would display "Do you want to play again? (y/n) ", wait for user input that starts with "y" or "n",
	 * and return true or false accordingly.
	 * 
	 * @param prompt to display before getting user input
	 * @return true if user input starts with "y", false if user input starts with "n"
	 */
	boolean askYesOrNo(String prompt, Scanner scanner) {

		//TODO Insert your code here
		System.out.println(prompt);
		try {
			String yesOrNoString=scanner.nextLine();//Scans for user input.
			yesOrNoString=yesOrNoString.toLowerCase();//Converts the user input to lowercase.
			String strippedString=yesOrNoString.strip();//Strips the updated user input's leading and trailing spaces.
			boolean yesOrNo=strippedString.startsWith("y");//Checks if the updated user input starts with "y."
			return yesOrNo;
		}
		catch(InputMismatchException e) {//Catches input mismatch error.
			boolean yesOrno=askYesOrNo(prompt,scanner);//Prompts the same question again till we get a valid input.
			return yesOrno;
		}
		
		
	}

	/**
	 * Returns a random "card", represented by an int between 1 and 10, inclusive.
	 * The "cards" are the numbers 1 through 10 and they are randomly generated, not drawn 
	 * from a deck of limited size.  The odds of returning a 10 are four times as likely 
	 * as any other value (because in an actual deck of cards, 10, Jack, Queen, and King all count as 10).
	 * @return random int between 1 and 10, inclusive
	 */
	int nextCard() {

		//TODO Insert your code here
		Random random=new Random();
		int card=random.nextInt(13)+1;//Assigns a random value from 1 to 13.
		if(card>=10) {
			card=10;//Values greater than 10 will also be assigned a value of 10 and total frequenchy of 10 is four.
		}
		return card;
	
	}

	/**
	 * Strategy for computer to take another card or not.  According to the computer’s own given
	 * total points (sum of visible cards + hidden card) and the user's sum of visible cards, you
	 * need to design a game strategy for the computer to win the game.
	 * 
	 * Returns true if the strategy decides to take another card, false if the computer decides not
	 * to take another card.
	 * 
	 * @param computerTotalPoints for the computer, the sum of visible cards + hidden card.
	 * @param userVisibleCards for the user, the sum of visible cards.
	 * @return true if the computer will take another card
	 */
	boolean takeAnotherCard(int computerTotalPoints, int userVisibleCards) {

		//TODO Insert your code here
		if(computerTotalPoints==21) {
			return false;//Does not take a new card if the total points is equal to 21.
		}
		else if(computerTotalPoints>=18) {
			if(computerTotalPoints<userVisibleCards) {
				return true;//If total points are more than or equal to 18, does not take a card unless total points is less than user visible points.
			}
			else {
				return false;//If total points are more than or equal to 18, does not take a card unless total points is less than user visible points.
			}
		}
		else if(computerTotalPoints<=11) {
			return true;//Always takes a card if the total points is less than or equal to 11.
		}
		else if(computerTotalPoints<userVisibleCards+5) {
				return true;//Takes a card if total points is less than visible points of user+5.
			}
		return false;
	}

	/**
	 * Determines if the game is over or not.
	 * If the given isUserPassed is set to true, the user has passed.
	 * If the given isComputerPassed is set to true, the computer has passed.
	 * This method returns true if both the user and the computer have passed,
	 * and false if either of them has not yet passed.
	 * @param isUserPassed is true if the user has passed
	 * @param isComputerPassed is true if the computer has passed
	 * @return true if both the user and the computer have passed 
	 */
	boolean isGameOver(boolean isUserPassed, boolean isComputerPassed) {

		//TODO Insert your code her
		if(!isUserPassed) {
			if(!isComputerPassed) {
				return false;//Game is over only when both the players pass.
			}
		}
		return true;//Game is not over even if one player does not pass.
		
	}

	/**
	 * In each turn, prints out the current status of the game.
	 * If isUser is set to true, the given player is the user.  In this case, print out
	 * the user's given name, his/her hidden card points, visible card points, and total points.
	 * If isUser is set to false, the given player is the computer.  In this case, print out
	 * the computer's given name, and his/her visible card points.
	 * 
	 * For example, calling printStatus(true, "Brandon", 4, 15, 19) would print:
	 * Brandon has 4 hidden point(s).
	 * Brandon has 15 visible point(s).
	 * Brandon has 19 total point(s).
	 * 
	 * As another example, calling printStatus(false, "Computer", 1, 19, 20) would print:
	 * Computer has 19 visible point(s).
	 * 
	 * @param isUser true if the given player is the user, false if the given player is the computer
	 * @param name of the given player
	 * @param hiddenCard the given player's hidden card points
	 * @param visibleCard the given player's visible card points
	 * @param totalPoints for the given player, the sum of visible cards + hidden card
	 */
	void printStatus(boolean isUser, String name, int hiddenCard, int visibleCard, int totalPoints) {

		//TODO Insert your code here
		System.out.println(name+" has "+hiddenCard+" hidden point(s).");//Prints hidden points.
		System.out.println(name+" has "+visibleCard+" visible point(s).");//Prints visible points.
		System.out.println(name+" has "+totalPoints+" total point(s).");//Prints total points.
		
		
	}

	/**
	 *  Determines who won the game and prints the game results in the following format:
	 *  - User's given name and the given user's total points
	 *  - Computer's given name and the given computer's total points
	 *  - The player who won the game and the total number of points he/she won by, or if it's a tie, nobody won
	 *  
	 * @param username for the user
	 * @param userTotalPoints for the user, the sum of visible cards + hidden card
	 * @param computerName for the computer
	 * @param computerTotalPoints for the computer, the sum of visible cards + hidden card
	 */
	void printWinner(String username, int userTotalPoints, String computerName, int computerTotalPoints) {
		System.out.println("--Game Over--");
		//TODO Insert your code here
		//If user has more points and it is less than 22, user wins.
		if(userTotalPoints>computerTotalPoints) {
			if(userTotalPoints<=21) {
				System.out.println(username+" is the winner!");
			}
		}
		//If the computer has more points and it is less than 22, computer wins.
		if(computerTotalPoints>userTotalPoints){
			if(computerTotalPoints<=21) {
				System.out.println(computerName+" is the winner!");
			}
		}
		//If computer has less points and user points is more than 21, computer wins.
		if(computerTotalPoints<userTotalPoints) {
			if(userTotalPoints>21) {
				System.out.println(computerName+" is the winner!");
			}
		}
		//if user has less points and if computer points is more than 21, user wins.
		if(userTotalPoints<computerTotalPoints) {
			if(computerTotalPoints>21) {
				System.out.println(username+" is the winner!");
			}
		}
		//If the points are equal or both the players have more than 21 points, it is a tie.
		if(userTotalPoints==computerTotalPoints||(userTotalPoints>21&&computerTotalPoints>21)){
			System.out.println("It is a tie.");
		}
		
				
	}
}