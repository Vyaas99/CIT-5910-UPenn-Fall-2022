/**
 * Given 5 numbers (ints or doubles), prints the sum (as a double) of the numbers, one by one.
 * 
 * @author lbrandon
 */
public class AddFiveNumbers {

	public static void main(String[] args) {
		
		//calculate the total sum of the following 5 numbers (doubles and ints), one by one
		double num1 = 3.2;
		int num2 = 1;
		double num3 = -1.0;
		int num4 = 3241;
		double num5 = -9.9;
		
		//store the sum as a double
		double sum = 0.0;
		
		
		//TODO Insert your code here
		sum+=num1;//adds num1 to sum which is zero.
		System.out.println("Sum:"+sum);
		sum+=num2;//adds num2 to sum which is num1.
		System.out.println("Sum:"+sum);
		sum+=num3;//adds num3 to sum.
		System.out.println("Sum:"+sum);
		sum+=num4;//adds num4 to sum.
		System.out.println("Sum:"+sum);
		sum+=num5;//adds num5 to sum.
		System.out.println("Sum:"+sum);//Have printed sum at every step as asked by the question.

		//Hint(s):
		//- Calculate the sum of the first 2 numbers, then print
		//- Add the second number, then print total sum
		//- Add the third number, then print total sum
		//- So on and so forth ...

				
	}
}
