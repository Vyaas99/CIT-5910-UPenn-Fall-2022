/**
 * Based on given prices, computes the total cost of a particular number of drinks and tacos.
 * 
 * Example(s): 
 * - If a drink costs 2.10 dollars and a taco costs 3.43 dollars, the total cost of 
 * 4 drinks and 6 tacos is 28.98.
 *  
 * @author lbrandon
 */
public class ComputingTotalCost {

	public static void main(String[] args) {

		//number of drinks
		int numDrinks = 2;
		//int numDrinks = 100;
		
		//number of tacos
		int numTacos = 3;
		//int numTacos = 100;

		//total cost
		double totalCost = 0.0;

		
		//TODO Insert your code here
		double costOfDrinks=numDrinks*2.10;//creating a double to store the total cost of drinks.
		System.out.println("The total cost for the drinks are "+costOfDrinks);//printing the total cost of drinks.
		double costOfTacos=numTacos*3.43;//creating a double to store the total cost of tacos.
		System.out.println("The total cost for the tacos are "+costOfTacos);//printing the total cost of tacos.
		totalCost=costOfDrinks+costOfTacos;//assigning the total cost of tacos and drinks to the variable-totalCost.
		System.out.println("Total Cost:"+totalCost);//printing the total cost.
		
		//A drink costs 2.10 dollars. A taco costs 3.43 dollars. 
		//Given the number of each, compute the total cost and assign to totalCost. 
		//For example: 4 drinks and 6 tacos yields totalCost of 28.98. 
		
		//Hint(s):
		//- Calculate total cost of drinks
		//- Calculate total cost of tacos
		//- Calculate total cost

		
	}
}