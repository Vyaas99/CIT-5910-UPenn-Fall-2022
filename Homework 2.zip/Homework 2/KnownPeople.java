/**
 * Based on a given number of your friends, calculates the total number of known people.
 * 
 * - For example, if you have 4 friends, then each of them knows 4 people.  Then each of those people also knows 4 people.  
 * This means there are 1 (yourself) + 4 + 16 + 64 = 85 total known people.  
 * 
 * @author lbrandon
 */
public class KnownPeople {
	
	public static void main(String[] args) {

		//number of your friends
		int yourFriends = 3;
		
		//calculate the total number of known people
		int totalKnownPeople = 0;
		
		
		//TODO Insert your code here
		int firstCircle=yourFriends;
		int secondCircle=yourFriends*yourFriends;
		int thirdCircle=yourFriends*yourFriends*yourFriends;
		totalKnownPeople=1+(yourFriends)+(yourFriends*yourFriends)+(yourFriends*yourFriends*yourFriends);
		//System.out.println(totalKnownPeople);
		System.out.println("You have "+firstCircle+" friends.");
		System.out.println("Each of them know "+firstCircle+"people, which means "+secondCircle+" more people.");
		System.out.println("Then each of those people also know 4 more people, which means "+thirdCircle+" more people.");
		System.out.println("This means that there are a total of "+totalKnownPeople+" known people.(including yourself)");
		//Hint(s):
		//- Considering the number of friends you have, calculate the number of people they know
		//- Then calculate the number of additional people those people know
		//- Considering yourself, calculate the total number of known people
		
		
	}
}