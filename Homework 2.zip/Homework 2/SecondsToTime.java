/**
 * Converts a given number of seconds (as an int) to hours:minutes:seconds.
 *
 * Example(s): 
 * - If input seconds is 1432, print in the format: 0:23:52
 * - If input seconds is 0, print in the format: 0:0:0
 *   
 * @author lbrandon
 */
public class SecondsToTime {

	public static void main(String[] args) {
		
		//number of seconds
		int seconds = 1234;
		//int seconds=5000;

		
		//TODO Insert your code here
		int hours=seconds/(60*60);//converts the input seconds into hours.
		//System.out.println(hours);
		seconds-=(hours*60*60);//subtracts the hours calculated from seconds by converting it into seconds and reassigning it back to seconds.
		int minutes= seconds/60;//converts the remaining seconds into minutes.
		//System.out.println(minutes);
		seconds-=minutes*60;//subtracting the minutes from the input seconds by converting it into seconds and reassigning it back to seconds.
		//System.out.println(seconds);
		System.out.println(hours+":"+minutes+":"+seconds);//prints the hours,minutes and seconds in the format asked in the question.
		
		//Hint(s):
		//- Calculate minutes
		//- Calculate remaining seconds
		//- Calculate hours
		//- Calculate remaining minutes 
	
		
	}
}
